/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec16.cpp
 */
#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>
#include <fstream>
#include <cctype>
#include <algorithm>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID


#include "lec16.h"

// Complete these functions
int divisible_by_n(const vector<int>& v, int n)
{
    int count{0};
    return count;
}

vector<int> unique(const vector<int>& v)
{
    vector<int> result;
    return result;
}

int unique(vector<int>& v)
{
    int dupes{0};
    return dupes;
}

vector<int> merge(const vector<int>& a, const vector<int>& b)
{
	vector<int> result;
    return result;
}

vector<Word> spell_check(istream& in,
                        const vector<string>& dictionary,
                        const vector<string>& excluded)
{
    vector<Word> result;

    // 1. Read through the input stream until end of file (while in)

        // 2. Consume any white space, so we are at the beginning of a word

        // 3. Find current position (in.tellg())
        
        // 4. If tellg() returns pos_type(-1) then at end of file
        
        // 5. Read next word, convert to lowercase, remove punctuation
        
        // 6. Search the list of misspelled words (results)
        //      Found? Append position to element where found, then continue
        
        // 7.  Search the list of excluded words for word
        //      Found? Ignore and continue (top of loop)
        
        // 8. Not found? Search the dictionary for word
        //     Found? Not misspelled. Ignore and continue
        
        // 9. Not found in the dictionary? The word is misspelled
        //      + Add a new entry to the results
        //        containing the word and position where found
    }
    return result;
}

/////////////// student TESTING ////////////////////
vector<string> file_to_words(const string& filename);
#include <sstream>
#include <iomanip>
int run()
{
    cout << "Student testing" << endl;

    // vector<string> dictionary = file_to_words("words");
    // vector<string> ignore_words = file_to_words("excluded.txt");
    // istringstream words("Now is the tyme for all good studunts to "
    //     "come to the aiid of their ai!id classmaates.");
    // vector<Word> misspelled = spell_check(words, dictionary, ignore_words);
    // cout << "Misspelled words" << endl;
    // int i{1};
    // for (const auto& e : misspelled)
    // {
    //     cout << setw(4) << i++ << ". " << e.word << ", [ ";
    //     for (auto pos : e.positions)
    //         cout << pos << " ";
    //     cout << "]" << endl;
    // }

    return 0;
}
