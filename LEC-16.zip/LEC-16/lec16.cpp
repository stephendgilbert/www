/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec16.cpp
 */
#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>
#include <fstream>
#include <cctype>
#include <algorithm>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID


#include "lec16.h"

// Place your functions here




/////////////// student TESTING ////////////////////
vector<string> file_to_words(const string& filename);
#include <sstream>
#include <iomanip>
int run()
{
    cout << "Student testing" << endl;

    // vector<string> dictionary = file_to_words("words");
    // vector<string> ignore_words = file_to_words("excluded.txt");
    // istringstream words("Now is the tyme for all good studunts to "
    //     "come to the aiid of their ai!id classmaates.");
    // vector<Word> misspelled = spell_check(words, dictionary, ignore_words);
    // cout << "Misspelled words" << endl;
    // int i{1};
    // for (const auto& e : misspelled)
    // {
    //     cout << setw(4) << i++ << ". " << e.word << ", [ ";
    //     for (auto pos : e.positions)
    //         cout << pos << " ";
    //     cout << "]" << endl;
    // }

    return 0;
}
