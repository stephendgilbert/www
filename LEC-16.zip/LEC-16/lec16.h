/**
    @file lec16.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef LEC16_H
#define LEC16_H
#include <vector>
#include <string>

using pos_type = std::istream::pos_type; // type of stream position
struct Word
{
    std::string word;
    std::vector<pos_type> positions;
};

/**
    Reads any stream until end-of-file. Returns a vector of misspelled words,
    but not those words that have been excluded.
    @param in the stream to read from
    @param dictionary vector of string containing correct-spelled words.
    @param excluded vector of string containing words to ignore.
    @return a vector of misspelled words, along with their position in the
        original file.
*/
std::vector<Word> spell_check(std::istream& in,
                    const std::vector<std::string>& dictionary,
                    const std::vector<std::string>& excluded);

/**
    Merges two sorted vectors by interleaving their elements.
    The resulting vector is also in sorted order.
    If different sizes, elements from the longer vector
    appear at the end.

    @param a the first vector.
    @param b the second vector.
    @return the merged vector.
*/
std::vector<int> merge(const std::vector<int>& a,
                       const std::vector<int>& b);
#endif
