/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec23.cpp
 */
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

#include "lec23.h"

string student = "Who Are You?";  // Add your Canvas login name
extern string assignment;

// Implement your member functions here


// Predefined functions for this exercise
int run()
{
    print_heading();

    Time start_time;
    Time duration;

    // Input section
    cout << "    Time: ";
    if (! start_time.read(cin)) { return die(); }
    cout << "    Duration: ";
    if (! duration.read(cin)) { return die(); }

    // Processing section
    Time after = start_time.sum(duration);
    Time before = start_time.difference(duration);

    // Output section
    cout << endl;
    duration.write(cout) << " hours after, and before, ";
    start_time.write(cout) << " is [";
    after.write(cout) << ", ";
    before.write(cout) << "]" << endl;

    return 0;
}

void print_heading()
{
    cout << student << "-" << assignment << ": Time and Again" << endl;
    cout << "------------------------------------------" << endl;
    cout << "Give me a time (such as 3:57) and a duration\n"
        << "(such as 1:05), and I'll tell you the sum\n"
        << "(that is, the time that follows the given time\n"
        << "by the given duration), and difference (the time that\n"
        << "precedes the given time by that duration)." << endl;
    cout << endl;
}

int die()
{
    cout << "[Failed Input]" << endl;
    cout.flush();
    return -1;
}
