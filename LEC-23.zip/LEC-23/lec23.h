/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec23.h
 */
#ifndef LEC23_H
#define LEC23_H

/** Prints [Input failed] and returns -1. */
int die();

/** Prints the heading for this exercise */
void printHeading();

// Add your user-defined type definition here
#include <iostream>
struct Time
{
    int hours, minutes;

    Time sum(const Time& rhs);
    Time difference(const Time& rhs);

    std::istream& read(std::istream& in);
    std::ostream& print(std::ostream& out);
};

#endif
