/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec23.h
 */
#ifndef LEC23_H
#define LEC23_H

/** Prints [Input failed] and returns -1. */
int die();

/** Prints the heading for this exercise */
void print_heading();

// Add your user-defined type definition here
#include <iostream>




#endif
