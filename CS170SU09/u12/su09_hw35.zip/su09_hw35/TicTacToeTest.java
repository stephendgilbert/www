import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TicTacToeTest
{

    private TicTacToe game;
    
    @Before
    public void setUp() throws Exception
    {
        game = new TicTacToe();
    }


    @Test
    public void testGetWinner_None()
    {
        game.set(0, 0, "X");
        game.set(2, 0, "O");
        game.set(1, 1, "X");
        game.set(2, 1, "O");
        
        assertEquals("No winner yet\n" + game.toString(),
            " ", game.getWinner());
        
     }

    @Test
    public void testGetWinner_X()
    {
        game.set(0, 0, "X");
        game.set(2, 0, "O");
        game.set(1, 1, "X");
        game.set(2, 1, "O");
        game.set(2, 2, "X");
        
        assertEquals("X should win\n" + game.toString(),
            "X", game.getWinner());
        
     }

    @Test
    public void testGetWinner_O()
    {
        game.set(0, 0, "X");
        game.set(2, 0, "O");
        game.set(1, 1, "X");
        game.set(2, 1, "O");      
        game.set(2, 2, "O");
        
        assertEquals("0 should win\n" + game.toString(),
            "O", game.getWinner());
        
     }

    @Test
    public void testGetWinner_Tie()
    {
        game.set(0, 0, "X");
        game.set(0, 1, "O");
        game.set(0, 2, "X");
        game.set(1, 0, "O");
        game.set(1, 1, "O");
        game.set(1, 2, "X");
        game.set(2, 0, "X");      
        game.set(2, 1, "X");      
        game.set(2, 2, "O");
        
        assertEquals("Tie game\n" + game.toString(),
            " ", game.getWinner());
        
     }

}
