import java.util.Scanner;

/**
   This program tests the getWinner method of the TicTacToe class.
*/
public class TicTacToeTester
{
   public static void main(String[] args)
   {
      TicTacToe game = new TicTacToe();
      game.set(0, 0, "X");
      game.set(2, 0, "O");
      game.set(1, 1, "X");
      game.set(2, 1, "O");
      System.out.println(game);
      System.out.println("Winner: " + game.getWinner());
      System.out.println("Expected: ");
      
      game.set(2, 2, "X");
      System.out.println(game);
      System.out.println("Winner: " + game.getWinner());
      System.out.println("Expected: X");

      game = new TicTacToe();
      game.set(0, 0, "X");
      game.set(2, 0, "O");
      game.set(1, 1, "X");
      game.set(2, 1, "O");      
      game.set(2, 2, "O");
      System.out.println(game);
      System.out.println("Winner: " + game.getWinner());
      System.out.println("Expected: O");            
   }
}
