/**
 * CS 170 Homework 34: a 3 x 3 Tic-Tac-Toe board.
 * @author (Your name goes here)
 * @version (today's date goes here)
 */
public class TicTacToe
{
    /**
     * Constructs an empty board.
     */
    public TicTacToe()
    {
        board = new String[ROWS][COLUMNS];

        // fill with spaces
        for ( int i = 0; i < ROWS; i++ )
            for ( int j = 0; j < COLUMNS; j++ )
                board[i][j] = " ";
    }


    /**
     * Sets a field in the board. The field must be unoccupied.
     * 
     * @param i the row index
     * @param j the column index
     * @param player the player ("X" or "0")
     */
    public void set( int i, int j, String player )
    {
        if ( board[i][j].equals( " " ) )
            board[i][j] = player;
    }


    /**
     * Creates a string representation of the board such as 
     * |X O| 
     * | X | 
     * |  O|
     * 
     * @return the string representation
     */
    public String toString()
    {
        String r = "";
        for ( int i = 0; i < ROWS; i++ )
        {
            r = r + "|";
            for ( int j = 0; j < COLUMNS; j++ )
                r = r + board[i][j];
            r = r + "|\n";
        }
        return r;
    }


    /**
     * Gets the winner
     * 
     * @return the winner
     */
    public String getWinner()
    {
        /**
         * Add your code here.
         */
        return " ";
    }

    private String[][] board;
    private static final int ROWS = 3;
    private static final int COLUMNS = 3;
}
