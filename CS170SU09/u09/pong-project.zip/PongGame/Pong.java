/**
 * The basic game of Pong.
 *
 *  @author Stephen Gilbert
 *  @version Feb 18, 2009 2:57:03 PM
 *
 */
public class Pong
{
    public static void main(String[] args) 
    {
        PongApp app = new PongApp(300,200);
        app.show();
    }
}
