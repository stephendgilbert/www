/**
    @file lec10.h
    @author
    @version
*/
#ifndef LEC10_H
#define LEC10_H
#include <string>

/**
    Write the recursive function triangle.
    @param height the height of the pyramid.

    We have pyramid made of blocks.
    The topmost row has 1 block, row beneath that
    has 2 blocks, the next row has 3 blocks, and so on.
    Compute recursively (no loops or multiplication) the
    total number of blocks in such a triangle with the given
    height. Notice that if there are no
    blocks, your function should return 0.

        triangle(0) returns 0
        triangle(1) returns 1
        triangle(2) returns 3
*/
int triangle(int height);

/**
    Write the function power.
    @param n the number to process
    @param exponent the exponent of the number

    Given n and exponent that are both 1 or more, compute
    recursively (no loops) the value of n to the exponent
    power, so power(3, 2) is 9 (3 to the 2nd power or 3 squared).

        power(3, 1) returns 3
        power(3, 2) returns 9
        power(3, 3) returns 27
*/
int power(int n, int exponent);

/**
    Write the function change_x2y.
    @param str the string to process

    Given a string, compute recursively (no loops) a
    new string where all the lowercase 'x' characters
    have been changed to 'y'

        change_x2y("codex") returns "codey"
        change_x2y("xxhixx") returns "yyhiyy"
        change_x2y("xhixhix") returns "yhiyhiy"
*/
std::string change_x2y(const std::string& str);

/**
    Recursively searches a string to find a second string.
    @param str the string to search through.
    @param target the string to search for
    @return true if target is found in str.

    Tests whether the string target is contained in a string str.
    For instance, calling the function like this:
        bool b = find("Mississippi", "sip");
    returns true, since "sip" is contained in "Mississippi".
    You must write this as a recursive function, not by just
    calling the string::find() function, or by using a loop.
*/
bool find(const std::string& str, const std::string& target);

/**
    Compute recursively a new string where adjacent characters
    that are the same have been reduced to a single character.
    So "yyzzza" yields "yza". Here are some more examples:
        string_clean("yyzzza") -> "yza"
        string_clean("abbbcdd") -> "abcd"
        string_clean("Hello") -> "Helo"
    @param str the string to start with.
    @return the string modified as described.
*/
std::string string_clean(const std::string& str);

#endif
