/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec10.cpp
 */
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "lec10.h"

// Place your function definitions in this file.




////////////////// STUDENT TESTING /////////////
int run()
{
    cout << "Student testing" << endl;
    return 0;
}

