#include <iostream>
#include <iomanip>
#include <ctime>
#include <chrono>
using namespace std;

long long recurse;

/**
   Computes a Fibonacci number.
   @param n an integer
   @return the nth Fibonacci number
*/
int fib(int n)
{
    recurse++;
    if (n < 2) return n;
    return fib(n-1) + fib(n-2);
}

int main()
{
    cout << "\nMeasuring Fibbonocci efficiency" << endl;
    cout << fixed << setprecision(0);

    // fib(10)
    recurse = 0;
    auto start = chrono::steady_clock::now();
    cout << "fib(10)->" << fib(10);
    auto stop = chrono::steady_clock::now();
    auto diff = stop - start;
    cout << " : " << chrono::duration<double, nano>(diff)
        .count() << " ns, recursive calls->" << recurse << endl;

    // fib(25)
    recurse = 0;
    start = chrono::steady_clock::now();
    cout << "fib(25)->" << fib(25);
    stop = chrono::steady_clock::now();
    diff = stop - start;
    cout << " : " << chrono::duration<double, nano>(diff)
        .count() << " ns, recursive calls->" << recurse << endl;

    // fib(35)
    recurse = 0;
    start = chrono::steady_clock::now();
    cout << "fib(35)->" << fib(35);
    stop = chrono::steady_clock::now();
    diff = stop - start;
    cout << " : " << chrono::duration<double, nano>(diff)
        .count() << " ns, recursive calls->" << recurse << endl;

    // fib(45)
    recurse = 0;
    start = chrono::steady_clock::now();
    cout << "fib(45)->" << fib(45);
    stop = chrono::steady_clock::now();
    diff = stop - start;
    cout << " : " << chrono::duration<double, nano>(diff)
        .count() << " ns, recursive calls->" << recurse << endl;


    cout << "\n -- done --" << endl;

    return 0;
}
