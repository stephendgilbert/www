/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec19.cpp
 */
#include <string>
#include <iostream>
using namespace std;

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID


#include "lec19.h"

// Implement your functions here





/////////////// STUDENT TESTING ////////////////////

int run()
{
    // Just some samples for class
    cout << "Try some code on your own" << endl;

    return 0;
}
