/**
    @file lec19.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef LEC19_H
#define LEC19_H

/**
 *  Calculates an alternating sum of the elements in a.
 *  @param a an array of const int.
 *  @param size the number of elements in the array.
 *  @pre #size is > 0
 *  @return the alternating sum of {a, b, c, d} -> a - b + c - d
 *  Don't worry about overflow of the result.
 */
int alternating_sum(const int a[], size_t size);

struct MinMax
{
    const double * min = nullptr;
    const double * max = nullptr;
};
/**
 * Returns pointers to the extreme values in the array.
 * @param a pointer the first element in an array of doubles
 * @param size the number of elements in the array.
 * @return a MinMax structure; nullptrs if size is 0.
 */
MinMax min_max(const double *ptr, size_t size);

/**
 * same_set: checks if a and b have the same set of ints.
 *  - ignores multiplicity and order.
 *
 * @param a array of const int.
 * @param aEnd a pointer to past-the-end of a.
 * @param b array of const int.
 * @param bEnd pointer to past-the-end of b.
 *
 * @pre #aEnd and #bEnd are > a and b
 *
 * @return true if a and b have the "same set" as described above.
 * @examples:
 *      1  4  9  16  9  7  4  9  11 and 11  11  7  9  16  4  1 are same set
 *      3 1 1 11 and 3 11 11 7 are not the same set because b contains a 7
 *
 */
bool same_set(const int *aBeg, const int *aEnd,
             const int *bBeg, const int *bEnd);

/**
 * Copies all even numbers from a to b.
 *
 * @param a array of const int.
 * @param aSize size of array a.
 * @param[out] b array of int to be filled in with even numbers.
 * @param[int, out] bSize declared size of b on entry; returns number of elements copied.
 *
 * @pre bSize >= aSize
 * @post b filled with even numbers from a.
 *      bSize set to number of even values copied.
 *
 * @throw illegal_length exception if size of b < size of a
 *
 */
void copy_evens(const int a[], size_t aSize, int b[], size_t& bSize);

/**
 * clique_count: counts the number of adjacent groups of two or more.
 *
 * @param a an array of const int.
 * @param aSize size of array a.
 *
 * @return the number of cliques in the array.
 *
 */
int clique_count(const int a[], size_t aSize);

/**
 * Rearranges the array so that every 7 is followed by an 11.
 *
 * @param[in,out] a an array of int.
 * @param aSize size of array a.
 *
 */
void seven_eleven(int a[], size_t aSize);

#endif
