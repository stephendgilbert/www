/**
    @file lec19.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef LEC19_H
#define LEC19_H

/**
 *  Calculates an alternating sum of the elements in a.
 *  @param a an array of const int.
 *  @param size the number of elements in the array.
 *  @pre #size is > 0
 *  @return the alternating sum of {a, b, c, d} -> a - b + c - d
 *  Don't worry about overflow of the result.
 */
int alternating_sum(const int a[], size_t size);

struct MinMax
{
    const double * min = nullptr;
    const double * max = nullptr;
};
/**
 * Returns pointers to the extreme values in the array.
 * @param a pointer the first element in an array of doubles
 * @param size the number of elements in the array.
 * @return a MinMax structure; nullptrs if size is 0.
 */
MinMax min_max(const double *ptr, size_t size);

/**
 * same_set: checks if a and b have the same set of ints.
 *  - ignores multiplicity and order.
 *
 * @param beg_a first element of an array of const int (a)
 * @param end_a a pointer to past-the-end of a.
 * @param beg_b first element of an array of const int (b)
 * @param end_b pointer to past-the-end of b.
 *
 * @pre #end_a and #end_b are > beg_a and beg_b
 *
 * @return true if a and b have the "same set" as described above.
 * @examples:
 *      1  4  9  16  9  7  4  9  11 and 11  11  7  9  16  4  1 are same set
 *      3 1 1 11 and 3 11 11 7 are not the same set because b contains a 7
 *
 */
bool same_set(const int * const beg_a, const int * const end_a,
             const int * const beg_b, const int * const end_b);

/**
 * clique_count: counts the number of adjacent groups of two or more.
 *
 * @param a an array of const int.
 * @param size size of array a.
 *
 * @return the number of cliques in the array.
 *
 */
int clique_count(const int a[], size_t size);

/**
 * Rearranges the array so that every 7 is followed by an 11.
 *
 * @param[in,out] a an array of int.
 * @param size size of array a.
 *
 */
void seven_eleven(int a[], size_t size);

#endif
