/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec07.cpp
 */
#include <string>
#include <cctype>
using namespace std;

string student = "Who Are You?";  // Add your Canvas login name

// Implement your function here


/////////////// Optional Student Code /////////////////
#include <iostream>
int run()
{
	// Add any code you like here
	// cout << R"(sum_nums("abc123xyz")->123? )" << sum_nums("abc123xyz") << endl;
	// cout << R"(sum_nums("aa11b33")->44? )" << sum_nums("aa11b33") << endl;
	// cout << R"(sum_nums("7 11")->18? )" << sum_nums("7 11") << endl;

    return 0;
}

