/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec22.cpp
 */
#include <string>
#include <iostream>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "lec22.h"

// Implement your functions here






//////////////////////// student TESTING //////////////////////////
#include <iostream>
#include <sstream>
int run()
{
    cout << "You may add your own tests here" << endl;
	{
		istringstream in("8 9 Q 4 5");
		FlexArray a;
		in >> a;
		cout << "a->" << a << endl;
	}
	{
		istringstream in("8 9 Q 4 5");
		FlexArray a;
		in >> a;
		cout << "a->" << a << endl;
	}

    return 0;
}
