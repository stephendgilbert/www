/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec22.cpp
 */
#include <string>
#include <iostream>
#include <cassert>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "lec22.h"

// Add your function here


//////////////////////// student TESTING //////////////////////////
#include <iostream>
#include <sstream>
int run()
{
    cout << "Add your own tests here" << endl;
//	{
//		istringstream in("8 9 Q 4 5");
//		FlexArray a;
//		in >> a;
//		cout << "a->" << a << endl;
//	}
//	{
//		istringstream in("8 9 Q 4 5");
//		FlexArray a;
//		in >> a;
//		cout << "a->" << a << endl;
//	}

    return 0;
}


