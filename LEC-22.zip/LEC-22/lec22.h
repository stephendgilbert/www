/**
    @file lec22.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
    // DON'T CHANGE THIS FILE
*/
#ifndef LEC22_H
#define LEC22_H
#include <iostream>

// Partially-filled 2D Array Exercises
const size_t kMaxCols = 10;

/**
 *  Average all active elements in a 2D partially-filled array.
 *  @param a a 2D array of int with a width of kMaxCols
 *  @param rows the effective number of rows being used
 *  @param cols the effective number of columns being used
 *  @return average of all active elements.
 */
double average(const int a[][kMaxCols], size_t rows, size_t cols=kMaxCols);

/**
 *  Average elements is specified column of 2D array.
 *  @param a a 2D array of int with a width of kMaxCols
 *  @param rows the effective number of rows being used
 *  @param cols the effective number of columns being used
 *  @param col the column to average.
 *  @return average of all active elements in the given column.
 */
double average(const int a[][kMaxCols], size_t rows, size_t cols, size_t col);

/**
 *  Average elements is specified row of 2D array.
 *  @param a a 1D array of int
 *  @param cols the effective number of columns being used
 *  @return average of all active elements in the given column.
 */
double average(const int a[], size_t cols=kMaxCols);


// Dynamic Memory Exercises
const size_t kInitialCapacity = 2;

struct FlexArray
{
    size_t m_size = 0;
    int * m_data = nullptr;
    ~FlexArray() { delete[] m_data; } // Destructor
};

/**
 * Read integers from a stream into a FlexArray.
 * @param[in] in the stream to read from.
 * @param[out] the FlexArray to store the data in
 * @return a reference to the modified FlexArray
 * @post m_size will contain the number of elements
 * @post m_data will contain exactly m_size elements
 * @post in will be at end of file or a non-integer
 */
FlexArray& read_data(std::istream& in, FlexArray& a);


/////////////////// IGNORE THESE ////////////////////////
/**
 * Return a string representation of a FlexArray.
 * @param a the array to represent.
 * @return a comma separated, brace delimited contents.
 */
std::string to_string(const FlexArray& a);

inline std::ostream& operator<<(std::ostream& out, const FlexArray& a)
{
    out << to_string(a);
    return out;
}

inline std::istream& operator>>(std::istream& in, FlexArray& a)
{
    read_data(in, a);
    return in;
}
#endif
