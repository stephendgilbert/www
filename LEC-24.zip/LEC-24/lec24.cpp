/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec24.cpp
 */
#include <string>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "lec24.h"

// Implement your class here






//////////////////////// student TESTING //////////////////////////
#include <iostream>
int run()
{
    cout << "Add your own tests here" << endl;
    // Bug fred(3);
    // fred.move();
    // cout << "fred is now at " << fred.position() << endl;

    return 0;
}
