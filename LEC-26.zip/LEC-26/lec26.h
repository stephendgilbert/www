/*
 *  lec26.h
 *  @author your name goes here
 *  @version your section and day
 *  Point->Circle->Cylinder
 */

#ifndef LEC26_H
#define LEC26_H

#include "point.h"
#include <cmath>
#include <string>

// Use this for PI
const double kPi = std::acos(-1.0);

//////// Put your class definitions here /////////////////////
// Put Circle first, then Cylinder



#endif
