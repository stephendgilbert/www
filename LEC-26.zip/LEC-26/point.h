/*
 *  point.h
 *  @author Stephen Gilbert
 *  @version Fall 2024
 *  Base class for CS 150 Exercise
 */

#ifndef POINT_H_
#define POINT_H_
#include <string>

class Point
{
public:
    /**
     * Construct a point object using default values. (0, 0)
     */
    Point() = default;

    /**
     * Construct a point object
     * @param x the horizontal value
     * @param y the vertical value
     */
    Point(double x, double y);

    /**
     * Moves a Point object
     * @param dx the amount to move x.
     * @param dy the amount to move y.
     */
    void move(double dx, double dy);

    /**
     * Returns the x value.
     * @return the x value.
     */
    double x() const;

    /**
     * Returns the y value.
     * @return the y value.
     */
    double y() const;

    /**
     * Returns the string representation.
     * @param decimals the number of decimal places to display
     *      If set to 0, then no decimals are shown including the .
     */
    virtual std::string to_string(int decimals = 2) const;

    /**
        Virtual inline destructor.
    */
    virtual ~Point() = default;
private:
    double m_x = 0;
    double m_y = 0;
};

#endif /* POINT_H_ */
