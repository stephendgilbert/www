/**
    @file lec26.cpp
    @author your name here
    @version what day and meeting time
*/
#include <string>
#include <stdexcept>
#include <sstream>
#include <iomanip>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "lec26.h"
///////// Add your code here ///////////////



//////////////// Student Tests ////////////////////////////
#include <iostream>
int run()
{
    cout << "Optional Student testing" << endl;
    return 0;
}
