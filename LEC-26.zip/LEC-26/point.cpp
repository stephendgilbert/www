/*
 *  point.cpp
 *  Implementation of a simple Point class.
 *  @author
 *  @version
 */

#include "point.h"
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

Point::Point(double x, double y) : m_x(x), m_y(y) { /* no code here */}

double Point::x() const { return m_x; }
double Point::y() const { return m_y; }

void Point::move(double dx, double dy) { m_x += dx; m_y += dy; }

string Point::to_string(int decimals) const
{
    ostringstream out;
    out << fixed;
    if (decimals > 0)
        out << showpoint << setprecision(decimals);
    else
        out << noshowpoint << setprecision(0);

    out << "Point(" << m_x << ", " << m_y << ")";

    return out.str();
}

