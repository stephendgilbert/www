/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec15.cpp
 */
#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>
#include <fstream>
#include <cctype>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "lec15.h"

// Implement your functions here





/////////////// STUDENT TESTING ////////////////////
int run()
{
    cout << "Student testing" << endl;

    // auto v = fileToWords("excluded.txt");
    // cout << "Excluded words:" << endl;
    // for (auto e : v) cout << " -" << e << endl;

    return 0;
}
