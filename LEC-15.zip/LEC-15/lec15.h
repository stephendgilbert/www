/**
    @file lec15.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef LEC15_H
#define LEC15_H
#include <vector>
#include <string>

/**
 * The Coin type represents US currency.
 */
enum class Coin
{
    Penny = 1,
    Nickel = 5,
    Dime = 10,
    Quarter = 25,
    Half = 50
};

/**
 * Returns a string representing the value of a Coin.
 * @param c the coin to convert
 * @return a string of "Penny", "Nickel", "Dime", "Quarter" or "Half-dollar"
 */
std::string to_string(Coin c);

/**
 * Returns a the double value of each coin
 * @param c the coin to convert
 * @return a decimal value for the coin (eg .25 for a quarter)
 */
double value_of(Coin c);


/**
 *  Opens a file and returns a vector<string> containing words.
 *  @param file_name contains the path needed to open the file.
 *  @return a vector<string> of words.
 */
std::vector<std::string> file_to_words(const std::string& file_name);


#endif
