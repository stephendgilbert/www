/**
    @file lec15.h
    @author Stephen Gilbert
    @version Declarations for CS 150 Homework
*/
#ifndef LEC15_H
#define LEC15_H
#include <vector>
#include <string>

/**
 *  Opens a file and returns a vector<string> containing words.
 *  @param file_name contains the path needed to open the file.
 *  @return a vector<string> of words.
 */
std::vector<std::string> file_to_words(const std::string& file_name);


#endif
