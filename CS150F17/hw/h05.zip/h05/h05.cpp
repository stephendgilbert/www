/**
    @file h05.cpp
    @author your name here
    @version what semester and meeting
*/
#include <string>
using namespace std;

string STUDENT = "put-your-id-here!!!"; // Add your name Blackboard/occ-email ID

#include "h05.h"

// Place your function definitions in this file.

