/**
    @author your name here
    @version what semester and meeting
    @file h04.cpp
*/
#include <string>
// Add additional headers as needed here

using namespace std;
string STUDENT = "put-your-id-here";    // Add your name Blackboard/occ-email ID

#include "h04.h"

// Place the implementation (definition) of your function here
