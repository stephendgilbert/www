/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec13.cpp
 */
#include <string>
#include <iostream>
#include <sstream>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

//////// Add your function implementations here



/////////////// STUDENT TESTING ////////////////////
#include <iostream>
int run()
{
    cout << "Student testing" << endl;

    return 0;
}
