#include <iostream>
#include <sstream>
#include <string>
using namespace std;

// #if __cplusplus < 201103L
// int stoi(const string& str) {
//     istringstream in(str);
//     int n;
//     in >> n;
//     return n;
// }

// double stod(const string& str) {
//     istringstream in(str);
//     double n;
//     in >> n;
//     return n;
// }

// string to_string(int n) {
//     ostringstream out;
//     out << n;
//     return out.str();
// }

// string to_string(double n) {
//     ostringstream out;
//     out << n;
//     return out.str();
// }
// #endif

int main() {
    cout << "stoi(\"42\")->" << stoi("42") << endl;
    cout << "stod(\"3.14159\")->" << stod("3.14159") << endl;
    cout << "to_string(42)->\"" << to_string(42) << '"' << endl;
    cout << "to_string(3.14159)->\"" <<  to_string(3.14159) << '"' << endl;
    cout << "to_string(1.32e-12)->\"" << to_string(1.32e-12) << '"' << endl;
}



