#include <iostream>
#include <string>
using namespace std;

int main() {
    cout << "stoi(\"42\")->" << stoi("42") << endl;
    cout << "stod(\"3.14159\")->" << stod("3.14159") << endl;
    cout << "to_string(42 )->" << to_string(42) << endl;
    cout << "to_string(3.14159)->" <<  to_string(3.14159) << endl;
}



