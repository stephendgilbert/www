/**
 *  @author Stephen Gilbert
 *  @version Tests for CS 150 homework
 *  @file tests.cpp
 */
#include <iostream>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <cmath>
using namespace std;

#include "cs150check.h"
#include "lec13.h"

ostringstream OUT;
istringstream IN;

#define CHECK_READINT(SIN, SOUT) { \
    OUT.clear(); OUT.str(""); cin.clear(); IN.str(SIN "\n -1"); IN.clear(); \
    int n = read_int(); \
    int expected = SOUT; \
    int actual = n; \
    EQM("get_int()<-"#SIN, expected, actual); \
}

#define CHECK_READINT_BAD(SIN, SOUT) { \
    OUT.clear(); OUT.str(""); cin.clear(); IN.str(SIN); IN.clear(); \
    int n = read_int(); \
    int expected = SOUT; \
    int actual = n; \
    EQM("get_int()<-"#SIN, expected, actual); \
}

#define CHECK_READINT_PROMPT(P, SIN, SOUT) { \
    OUT.clear(); OUT.str(""); cin.clear(); IN.str(SIN); IN.clear(); \
    int n = read_int(P); \
    string expected = P; \
    if (expected.size() > 0 && expected.at(expected.size() - 1) != ' ') expected += ' '; \
    string actual = OUT.str(); \
    EQM("Prompt "#P, expected, actual); \
    EQM("get_int()<-"#SIN, SOUT, n); \
}

/**
 * Run your program's tests
 */
void runTests()
{

	//    ///////////// Begin a set of tests
    beginTests(); // test heading

#if __cplusplus <= 199711L
    cerr << "Testing using C++98" << endl;
    cerr << "------------------------------------------" << endl;
#else
    cerr << "Testing using C++11 or greater" << endl;
    cerr << "------------------------------------------" << endl;
#endif
    beginFunctionTest("to_string function");

    EQM("to_string(42)", "42", to_string(42));
    EQM("to_string(3.F)", "3.000000", to_string(3.F));
    EQM("to_string(-1U)", "4294967295", to_string(-1U));
    EQM("to_string(4L)", "4", to_string(4L));
    EQM("to_string(1.7L)", "1.700000", to_string(1.7L));
    EQM("to_string(1.32e-4)", "0.000132", to_string(1.32e-4));

    endFunctionTest();

  	beginFunctionTest("sto?() Functions"); // function name
    try {
      EQ(123, stoi(" 123 "));
    } catch (const invalid_argument& e) {
      failMsg(string("stoi(\" 123 \"): SHOULD NOT throw invalid_argument"));
    }

    try {
      EQ(456, stoi("456"));
    } catch (const invalid_argument& e) {
      failMsg(string("stoi(\"456\"): SHOULD NOT throw invalid_argument"));
    }

    try {
      stoi("one");
      failMsg("stoi(\"one\") should fail.");
    } catch (const invalid_argument& e) {
      passMsg(string("stoi(\"one\") throws invalid_argument"));
    }

    try {
      stoi("5999999999");
      failMsg("stoi(\"5999999999\") should fail.");
    } catch (const out_of_range& e) {
      passMsg(string("stoi(\"5999999999\") throws out_of_range"));
    }

    const double kEpsilon = 1e-12;
    try {
      EQD(3.15, stod(" 3.15 "), kEpsilon);
    } catch (const invalid_argument& e) {
      failMsg(string("stod(\" 3.15 \") SHOULD NOT throw invalid_argument"));
    }

    try {
      stod("PI");
      failMsg("stod(\"PI\") should fail.");
    } catch (const invalid_argument& e) {
      passMsg(string("stod(\"PI\") throws invalid_argument"));
    }

    try {
      stod("9e310");
      failMsg("stod(\"9e310\") should fail.");
    } catch (const out_of_range& e) {
      passMsg(string("stod(\"9e310\") throws out_of_range"));
    }

    endFunctionTest(); // end

    endTests();
}

