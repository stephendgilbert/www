/**
    @file lec13.h
    @author Your name
    @data Semester and Section
*/
#ifndef LEC13_H
#define LEC13_H
#include <string>
#include <sstream>
#include <iomanip>
#include <typeinfo>


/**
 * Converts a string to an integer.
 * @param str the string to convert.
 * @return the integer value of str if convertible
 * @exception throws const string& with invalid value.
 */
int parse_int(const std::string& str);

/**
 * Reads an integer from the keyboard.
 * @param prompt to print before the input.
 * @return the integer read from the keyboard.
 * @post always returns.
 */
int read_int(const std::string& prompt="");


///////// Add your C++98 to_string template here ////////


#endif

