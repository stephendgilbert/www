/**
    @file lec13.h
    @author Your name
    @data Semester and Section
*/
#ifndef LEC13_H
#define LEC13_H
#include <string>
#include <sstream>
#include <iomanip>
#include <typeinfo>


#if __cplusplus <= 199711L

template <typename T>
std::string to_string(const T& value)
{
    std::ostringstream out;
    out << std::fixed;
    out << value;
    return out.str();
}

#endif
#endif

