/**
    @file lec13.h
    @author Your name
    @data Semester and Section
*/
#ifndef LEC13_H
#define LEC13_H
#include <string>
#include <sstream>
#include <iomanip>
#include <typeinfo>


// Add your prototypes for C++98

#endif

