/**
    @file lec13.h
    @author Your name
    @data Semester and Section
*/
#ifndef LEC13_H
#define LEC13_H
#include <string>
#include <sstream>
#include <iomanip>
#include <typeinfo>


#if __cplusplus <= 199711L

/**
 * Converts a string to an integer.
 * @param str the string to convert.
 * @return the integer value of str if convertible
 * @exception throws invalid_argument with invalid value.
 * @exception throws out_of_range with out-of-range value.
 */
int stoi(const std::string& str);

/**
 * Converts a string to an double.
 * @param str the string to convert.
 * @return the double value of str if convertible
 * @exception throws invalid_argument with invalid value.
 * @exception throws out_of_range with out-of-range value.
 */
double stod(const std::string& str);


/**
 * Converts an int to a string.
 * @param value the int to convert.
 * @return the string represention, default format.
 */
std::string to_string(int value);

#endif

#endif

