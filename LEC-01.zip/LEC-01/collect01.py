#!/usr/bin/env python3
print('Collecting files for LEC-01')
import os
if os.getenv('CS150USER') == '':
    print('You must configure your system first!')
    exit()
os.system('echo LEC-01 results for $CS150USER > results.txt')
os.system('echo ----------------------------- >> results.txt')
os.system('echo // hello.cpp - Source code >> results.txt')
os.system('cat hello.cpp >> results.txt')
os.system('echo ----------------------------- >> results.txt')
os.system('echo Stages of compilation >> results.txt')
os.system('clang++ hello.cpp -o hello -ccc-print-phases 2>> results.txt')
os.system('echo ----------------------------- >> results.txt')
os.system('echo Preprocessor >> results.txt')
os.system('head hello.ii >> results.txt')
os.system('echo ----------------------------- >> results.txt')
os.system('echo  Assembly Code >> results.txt')
os.system('tail hello.s >> results.txt')
os.system('echo ----------------------------- >> results.txt')
os.system('echo  Running the program >> results.txt')
os.system('./hello >> results.txt')



