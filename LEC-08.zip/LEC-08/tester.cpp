/**
 *  @date CS 150 Tests for algolib
 */
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <fstream>
using namespace std;

#include "cs150check.h"

///////////// Add header for function being tested


//////////// Add your student ID here
string student = "Who are you?";    // Canvas ID

void runTests()
{
	srand(time(0));

	///////////// Begin a set of tests
	beginTests(); // test heading

    /////// Tests for function //////////////////////
	beginFunctionTest("Put the title here"); // Test title
    
    // assertEquals(expected, actual);  // strings and ints (fruitful)
    // assertEqualsD(expected, actual, tolerance);  // doubles
    // assertEquals(expected, (call(arg), arg)); // procedure

    endFunctionTest(); // end

    ///////// End all test runs /////////////////////////
    endTests();
}

//////////// Student tests or run
int run()
{
    // Add code you want to display here
    return 0;
}
