#include <iostream>
#include <string>
using namespace std;

string student = "Who are you?"; // Add your Canvas id here.

#include "lec20.h"

// Define your functions here


/////////////// student TESTING ////////////////////
#include <iostream>
int run()
{
    cout << "Student testing" << endl;
//    int a[100] = {1, 2, 3, 4, 5, 6};
//    size_t size = 5;
//    if (erase(a, size, 3)) {
//        cout << "Success" << endl;
//    }
//    else {
//        cout << "Fail" << endl;
//    }
    return 0;
}
