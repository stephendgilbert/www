#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <stdexcept>
#include <vector>
using namespace std;

#include "search.h"

string STUDENT = "WHO AM I?"; // Add your Canvas/occ-email ID


// ADD RECURSIVE BINARY SEARCH HERE
bool binary_search(const vector<string>& dictionary,
            const string& word, int& compares)
{
    return false;
}

// ADD RECURSIVE BINARY SEARCH HELPER HERE
bool binary_helper(const vector<string>& dictionary,
            const string& word, size_t begin, size_t end, int& compares)
{
    return false;
}

vector<WORD> spell_check(istream& in,
        const vector<string>& dictionary, const vector<string>& exclude)
{
    vector<WORD> words;

    string word;
    while (in)
    {
        long pos = in.tellg();
        if (pos == -1)
            break;
        in >> word;

        cleanUp(word);
        // remove leading and trailing punctuation
        if (word.length() == 0 || word[0] == '\0')
            continue;

        bool done = false;
        // 1. look through misspelled words already encountered
        for (size_t i = 0, len = words.size(); i < len; ++i)
        {
            if (words.at(i).word == word)
            {
                words[i].pos.push_back(pos);
                done = true;
                break;
            }
        }

        if (done) continue;

        // 2. look through excluded words (shorter than dictionary)
        for (size_t i = 0, len = exclude.size(); i < len; ++i)
        {
            if (exclude.at(i) == word)
            {
                done = true;
                break;
            }
        }

        if (done) continue;

        // 3. See if the word is in the dictionary
        //// LINEAR SEARCH - REPLACE WITH RECURSIVE BINARY SEARCH
        int compares = 0;
        if (testNo == 1)
        {
            for (unsigned i = 0; i < dictionary.size(); i++)
            {
                compares++;
                if (word == dictionary[i])
                {
                    done = true;
                    break;
                }
            }
        }
        else if (testNo == 2)
        {
            done = binary_search(dictionary, word, compares);
        }
        else if (testNo == 3)
        {
            // Probably need to handle a 0-sized dictionary
            done = binary_helper(dictionary, word, 0, dictionary.size() - 1, compares);
        }

        if (done) continue;


        // Got here so we have a new misspelled word
        WORD w;
        w.word = word;
        w.pos.push_back(pos);
        w.compares = compares;
        words.push_back(w);
    }

    return words;
}
