/**
 * CS 150 partially-filled arrays.
 * @version Fall 2024
 * @author Stephen Gilbert
 * @file lec20.h
 */
#ifndef LEC20_H
#define LEC20_H
#include <string>
#include <sstream>

const size_t kNotFound = static_cast<size_t>(-1);

/**
 * Converts an array to its string representation.
 * @param a the array
 * @param size the number of the elements
 * @return a string in this form "[1 2 3]"
 */
std::string to_string(const int a[], size_t size);

/**
 * Reads from cin and stores values at the end of the array
 * @param[in,out] a the array
 * @param capacity the maximum number of elements
 * @return the current size of the array"
 */
std::size_t read_array(int a[], size_t capacity);

/**
 * Finds the index of a value in an array
 * @param a the array
 * @param size the number of elements
 * @param value the element to search for
 * @return position of first occurance of val or NOT_FOUND
 */
std::size_t index_of(const int a[], size_t size, int val);

/**
 * Erases a value from the array a, keeping the elements in order.
 * @param[in,out] a the array
 * @param[in,out] size the number of active elements
 * @param val the value to search for
 * @return true if an element was removed, false otherwise
 */
bool erase(int a[], size_t& size, int value);

/**
 * inserts value int to array a, keeping the elements in order.
 * @param a the array
 * @param size the address of the size of the elements
 * @param capcity the maximum elements in the array
 * @param value the value to add
 * @return a pointer to the added value (success) or nullptr (failure)
 */
int* insert(int a[], size_t& size, size_t capacity, int value);

#endif
