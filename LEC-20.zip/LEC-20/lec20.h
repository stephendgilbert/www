/**
 * CS 150 partially-filled arrays.
 * @version Fall 2024
 * @author Stephen Gilbert
 */
#ifndef LEC20_H
#define LEC20_H
#include <string>
#include <sstream>

const size_t kNotFound = static_cast<size_t>(-1);

/**
 * Finds the index of a value in an array
 * @param a the array
 * @param size the number of elements
 * @param value the element to search for
 * @return position of first occurance of val or kNotFound
 */
std::size_t index_of(const int a[], size_t size, int val);

/**
 * Converts an array to its string representation.
 * @param a the array
 * @param size the number of the elements
 * @return a string in this form "[1 2 3]"
 */
std::string to_string(const int a[], size_t size);

/**
 * Reads from cin and stores values at the end of the array
 * @param[in,out] a the array
 * @param capacity the maximum number of elements
 * @return the current size of the array"
 */
std::size_t read_array(int a[], size_t capacity);

/**
 * Erases a value from the array a, keeping the elements in order.
 * @param[in,out] a the array
 * @param[in,out] size the number of active elements
 * @param val the value to search for
 * @return true if an element was removed, false otherwise
 */
bool erase(int a[], size_t& size, int value);

/**
 * inserts value int to array a, keeping the elements in order.
 * @param a the array
 * @param size the address of the size of the elements
 * @param capcity the maximum elements in the array
 * @param value the value to add
 * @return a pointer to the added value (success) or nullptr (failure)
 */
int* insert(int a[], size_t& size, size_t capacity, int value);

/**
 * Copies all even numbers from a to b.
 *
 * @param a array of const int.
 * @param size_a size of array a.
 * @param[out] b array of int to be filled in with even numbers.
 * @param[int, out] size_b declared size of b on entry; set to number of elements copied.
 *
 * @pre size_b >= size_a
 * @post b filled with even numbers from a.
 *      size_b set to number of even values copied.
 *
 * @throw illegal_length exception if size of b < size of a
 *
 */
void copy_evens(const int a[], size_t size_a, int b[], size_t& size_b);

#endif
