CREATE TABLE CityZone (City CHAR(40), Zone CHAR(40))
INSERT INTO CityZone VALUES ('San Francisco', 'America/Los_Angeles')
INSERT INTO CityZone VALUES ('Kaoshiung', 'Asia/Taipei')
SELECT * FROM CityZone
