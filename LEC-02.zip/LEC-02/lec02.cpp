/**
 *  @author Put your Canvas ID here
 *  @date Put the date here (Semester is OK)
 *  @file lec02.cpp
 */
#include <iostream>
#include <string>
using namespace std;

string student = "WHO ARE YOU?";  // Add your Canvas login name
extern string assignment;

/**
 * One line describing what this program does.
 * @return 0 for success.
 */
int run()
{
    // Add your implementation comments here

    // Write your code here

    return 0;
}

