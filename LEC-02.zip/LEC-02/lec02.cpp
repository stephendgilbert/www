/**
 *  @author Put Canvas ID here
 *  @date Put your semester and section here
 *  @file lec02.cpp
 */
#include <iostream>
#include <string>
using namespace std;

string student = "Who Are You?";  // Add your Canvas login name
extern string assignment;

/**
 * Calculates the boxes of cereal in a metric ton.
 * @return 0 for success.
 */
int run()
{
    // Add implementation comments here

    // Write your code here

    return 0;
}

