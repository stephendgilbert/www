/**
    @file lec09.h
    @author Stephen Gilbert
    @version Fall 2024
*/
#ifndef LEC09_H
#define LEC09_H
#include <string>

/**
 * Reads an integer from standard input.
 * @param prompt the prompt to print before input
 * @param n the integer to initialize using std::cin
 * @param readln if true, consume input on line following successful input
 * @return true if successful, false, otherwise
 */
bool read(const std::string& prompt, int& n, bool readln=false);

/**
 * Reads a double from standard input.
 * @param prompt the prompt to print before input
 * @param d the double to initialize using std::cin
 * @param readln if true, consume input on line following successful input
 * @return true if successful, false, otherwise
 */
bool read(const std::string& prompt, double& n, bool readln=false);

/**
 * Reads a string from standard input.
 * @param prompt the prompt to print before input
 * @param str the string to initialize using std::cin
 * @param readln if true, read entire line, otherwise read a token
 * @return the value of the ln parameter
 */
bool read(const std::string& prompt, std::string& str, bool readln=false);

/**
 * Reads a char from standard input
 * @param c the character to initialize using std::cin
 * @param sentinel the character to compare with c
 * @return if c matches sentinal return false, otherwise true
 */
bool read(char& c, char sentinel);

/**
    Recursively searches a string to find a second string.
    @param str the string to search through.
    @param target the string to search for
    @return true if target is found in str.

    Tests whether the string target is contained in a string str.
    For instance, calling the function like this:
        bool b = find("Mississippi", "sip");
    returns true, since "sip" is contained in "Mississippi".
    You must write this as a recursive function, not by just
    calling the string::find() function, or by using a loop.
*/
bool find(const std::string& str, const std::string& target);

/**
    Compute recursively a new string where adjacent characters
    that are the same have been reduced to a single character.
    So "yyzzza" yields "yza". Here are some more examples:
        string_clean("yyzzza") -> "yza"
        string_clean("abbbcdd") -> "abcd"
        string_clean("Hello") -> "Helo"
    @param str the string to start with.
    @return the string modified as described.
*/
std::string string_clean(const std::string& str);
#endif
