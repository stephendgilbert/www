/**
    @file lec09.h
    @author
    @version
*/
#ifndef LEC09_H
#define LEC09_H
#include <string>

/**
 * Reads an integer from standard input.
 * @param prompt the prompt to print before input
 * @param n the integer to initialize using std::cin
 * @param readln if true, consume input on line following successful input
 * @return true if successful, false, otherwise
 */
bool read(const std::string& prompt, int& n, bool readln=false);

/**
 * Reads a double from standard input.
 * @param prompt the prompt to print before input
 * @param d the double to initialize using std::cin
 * @param readln if true, consume input on line following successful input
 * @return true if successful, false, otherwise
 */
bool read(const std::string& prompt, double& n, bool readln=false);

/**
 * Reads a string from standard input.
 * @param prompt the prompt to print before input
 * @param str the string to initialize using std::cin
 * @param readln if true, read entire line, otherwise read a token
 * @return the value of the ln parameter
 */
bool read(const std::string& prompt, std::string& str, bool readln=false);

/**
 * Reads a char from standard input
 * @param c the character to initialize using std::cin
 * @param sentinel the character to compare with c
 * @return if c matches sentinal return false, otherwise true
 */
bool read(char& c, char sentinel);


#endif
