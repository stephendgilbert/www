/**
    @file lec25.h
    @author Stephen Gilbert
    @version Fall 2024
    Do not change this file.
*/
#ifndef LEC25_H
#define LEC25_H
#include <vector>
#include <string>
#include <cassert>

using UC = unsigned char;
struct Pixel {UC red=0, green=0, blue=0, alpha=255;};
const Pixel kGray{128, 128, 128, 255};
const Pixel kTransparent{0, 0, 0, 0};

class Image
{
public:
    // Constructors
    Image() = default;
    Image(unsigned width, unsigned height);
    explicit Image(const std::string& path);

    // Accessors
    unsigned width() const;
    unsigned height() const;
    unsigned size() const;

    // Iterator support
    Pixel* begin();
    Pixel* end();

    // Mutators
    void fill(const Pixel& color);

    // Load and save
    bool load(const std::string& path);
    bool save(const std::string& path) const;

private:
    unsigned m_width{0}, m_height{0};
    vector<Pixel> m_pixels;
};

// Functions from stb_image and stb_image_write
// These are C functions
extern "C" {
unsigned char* stbi_load(const char* file_name,
    int* width, int* height, int* bytes_per_pixel,
    int desired_bpp=4);

 int stbi_write_png(const char* f_name, int width, int height,
    int channels, const void *data, int stride);
 int stbi_write_bmp(const char* f_name, int width, int height,
    int channels, const void *data);
 int stbi_write_jpg(const char* f_name, int width, int height,
    int channels, const void *data, int quality);

 void stbi_image_free (void *);
};

#endif
