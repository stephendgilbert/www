/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec06.cpp
 */
#include <string>
#include <iostream>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID
extern string assignment;

#include "lec06.h"

// Place your function definitions in this file.




////////////////// STUDENT TESTING /////////////
int run()
{
    cout << "Student testing" << endl;
    // prefixAgain("abXYabc", 1);
    return 0;
}
