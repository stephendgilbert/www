/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec14.cpp
 */
#include <string>
#include <cmath>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "lec14.h"
// Add your implementation here



/////////////// student TESTING ////////////////////
#include <sstream>
int run()
{
    cout << "Student testing" << endl;
    // istringstream in("3, 4");
    // Point p1;
    // get(in, p1);
    // print(cout, p1);
    return 0;
}
