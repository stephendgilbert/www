// Put your implementation here
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

#include "stars.h"


/////////////////// TESTING THE FUNCTIONS //////////////////
int main()
{
    cout << "Testing read and write" << endl;
    ifstream in("stars.txt");
    Star s;
    while (read(in, s))
    {
        if (! s.name1.empty() && s.magnitude > 6)
            write(cout, s) << endl;
    }
}
