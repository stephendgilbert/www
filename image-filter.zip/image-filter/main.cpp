/**
 * Sample code for stb_image* (CS 150)
 * @author Steve G.
 */
#define STB_IMAGE_IMPLEMENTATION        // REQUIRED (loading)
#define STB_IMAGE_WRITE_IMPLEMENTATION  // (writing)
#include "stb_image.h"                  // "header-only" C libraries
#include "stb_image_write.h"
 
#include <iostream>
using namespace std;

int main()
{
    // Load a jpg file using 3 bytes per pixel
    int width, height, bpp, channels = 3;
    unsigned char * const pete = 
        stbi_load("pete.jpg",               // input file
                    &width, &height, &bpp,  // pointers (out)
                    channels);              // channels (in)
    
    // Do the exercises
    
    // Now, write it out in current folder as a 3-bytes-per-pixel PNG
    stbi_write_png("pete.png", width, height, channels, pete, 
                    width * channels);
    
    // IMPORTANT - free the memory
    stbi_image_free(pete);
}
