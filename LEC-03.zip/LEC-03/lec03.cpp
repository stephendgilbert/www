/**
 *  @author Put Canvas ID here
 *  @date Put your semester and section here
 *  @file lec03.cpp
 */
#include <iostream>
#include <string>
#include <iomanip>
#include <string_view>
using namespace std;

string student = "Who Are You?";  // Add your Canvas login name
extern string assignment;

// Add your function declarations here

/**
 * Does some time arithmetic.
 * @return 0 for success.
 */
int run()
{
    // Print title and instructions
    print_instructions();

    // Get the user's input
    int time = get_hours_minutes("Time: ");
    int duration = get_hours_minutes("Duration: ");

    // Calculate times before and after
    int after = time + duration;
    int before = time + 1440 - duration; // No negative times

    // Print the output line
    print_output(time, duration, before, after);

    return 0;
}

// Add your function definitions here
