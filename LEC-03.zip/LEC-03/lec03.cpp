/**
 *  @author Put Canvas ID here
 *  @date Put your semester and section here
 *  @file lec03.cpp
 */
#include <iostream>
#include <string>
#include <iomanip>
#include <string_view>
using namespace std;

string student = "Who Are You?";  // Add your Canvas login name
extern string assignment;

// Add your function declarations here

/**
 * Does some time arithmetic.
 * @return 0 for success.
 */
int run()
{
    // Print title and instructions
    print_instructions();

    // Get the user's input
    cout << endl;   // newline
    int time = get_hours_minutes("Time: ");
    int duration = get_hours_minutes("Duration: ");
    cout << endl;   // newline

    // Calculate times before and after
    int after = time + duration;
    const int kMinutesPerDay = 60 * 24; // 1440
    int before = time + minutesPerDay - duration; // No negative times

    // Print the output line
    print_output(time, duration, before, after);

    return 0;
}

// Add your function definitions here
