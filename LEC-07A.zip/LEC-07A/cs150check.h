/**
 * Basic unit tests for CS 150
 * @author Stephen Gilbert
 */
#ifndef CS150CHECK_H
#define CS150CHECK_H

#include <iostream>
#include <sstream>
#include <iterator>
#include <string>
#include <vector>

extern std::string student;
extern std::string assignment;

/**
 * Print error messages for all of the assertEquals() methods
 * This is usually called from a macro that "stringifies" the actual argument
 * 	- Also increments the fail counter.
 *
 * @param msg usually the actual function under test (stringified by the macro)
 * @param expected expected value (of any type)
 * @param actual value of any type
 */
template <class T>
void _failReportEquals(const std::string& msg, [[maybe_unused]] const T& expected, const T& actual, int points=1)
{
    // Changed for H04
// 	std::cerr << "   X " << msg << ": expected [" << expected;
// 	std::cerr << "] but found [" << actual;
// 	std::cerr << "]" << std::endl;
 	std::cerr << "   X " << msg << ": Incorrect [" << actual << "]" << endl;;
	extern int fail;
	fail += points;
}

/**
 * Prints the success message for a test.
 * @param msg the message to print
 */
void _successReport(const std::string& msg);

/**
 * Prints the fail message for the non-assertEquals types methods.
 * 	- also increments the fail counter.
 *
 * @param msg the message to print
 * @param points the number of points for this problem.
 */
void _failReport(const std::string& msg, int points = 1);

//////////// OVERLOADED VERSION OF ASSERT_EQUALS ///////////////////////
/**
 * For string parameters. Called from a macro.
 * @param msg - usually the stringified expression used to calculate "actual"
 * @param expected - expected string
 * @param actual - actual string.
 */
void _assertEquals(const std::string& msg, const std::string& expected, const std::string& actual, int points=1);

/**
 * For int parameters. Called from a macro.
 * @param msg - usually the stringified expression used to calculate "actual"
 * @param expected - expected string
 * @param actual - actual string.
 */
void _assertEquals(const std::string& msg, int expected, int actual, int points=1);

/**
 * For double parameters. Called from a macro.
 * @param msg - usually the stringified expression used to calculate "actual"
 * @param expected - expected value
 * @param actual - actual actual
 * @param t - tolerance (defaulted)
 */
const double DEF_EPSILON = 1.e-14;
void _assertEquals(const std::string& msg, double e, double a, double t=DEF_EPSILON);

/**
 * Assert that a condition is true.
 * @param msg the message to display if failing.
 * @param cond the condition to check.
 */
void _assertTrue(const std::string& msg, bool cond);

/**
 * Assert that some condition is false.
 * @param msg the message to display if condition is true.
 * @param cond the condition that should be false.
 */
void _assertFalse(const std::string& msg, bool cond);

/**
 * Fails and prints an error message.
 * @param msg the message to display.
 * @param points to subtract (default = 1)
 */
void failMsg(const std::string& msg, int points = 1);

/**
 * Passes and prints a message.
 * @param msg the message to display.
 */
void passMsg(const std::string& msg, int points = 1);

/**
 * Begin a set of tests (sets everything to 0)
 */
void beginTests(bool instructor=true);

/**
 * Begins a function test. Sets the "current" test counter to 0.
 * @param functionName the function to test.
 */
void beginFunctionTest(const std::string& functionName);

/**
 * Ends a group of function tests.
 */
void endFunctionTest();

/**
 * Ends a suite of tests.
 */
void endTests(bool instructor=true);

/**
 * Runs the tests for these functions.
 */
int runTests();

/**
 * Run some IOTESTS
 */
int runIOTests(const vector<string>& tests, bool instructor=true);
vector<string> getData(const string& testFile);

/**
 * Run without tests.
 */
int run();


///////////////////////// SOME NEW UTILITY FUNCTIONS FOR ARRAYS ////////////////////
template <class T>
std::string aToStr(const T* a, size_t n)
{
    std::ostringstream sout;
    if (n > 0)
    {
        sout << a[0];
        for (size_t i = 1; i < n; i++)
            sout << ", " << a[i];
    }
    return sout.str();
}

template <class T>
void printAerr(const T* a, size_t n)
{
    std::cerr << aToStr(a, n);
}

template <class T>
void _assertArrayEquals(const std::string& msg, const T* expected, const T* actual, size_t n, int points=0)
{
    extern int possible;
    possible += points;
	std::string e = aToStr(expected, n);
	std::string a = aToStr(actual, n);
    if (e != a)
    {
        _failReportEquals(msg, e, a, points);
    }
    else
        _successReport(msg);
}

///////////////////////// SOME NEW UTILITY FUNCTIONS FOR VECTORS ////////////////////
/**
    Prints a vector int the form [e1, e2, e3].
    @param out the output stream
    @param v the vector of type T
    @return the modified output stream.
*/
template <typename T>
std::ostream& operator<<(std::ostream& out, const std::vector<T>& v)
{
    out << "[";
    if (v.size() > 0)
    {
        out << v.at(0);
        for (size_t i = 1, len = v.size(); i < len; i++)
            out << ", " << v.at(i);
    }
    out << "]";
    return out;
}

/**
    Converts a vector to its string equivalent.
    @param v the vector of type T
    @return a string in the form [e1, e2, e3]
*/
template <typename T>
const std::string vToStr(const std::vector<T>& v)
{
    std::ostringstream sout;
    sout << v;
    return sout.str();
}

//////////// MACROS USED TO CALL ASSERTS ////////////////////////
#define EQU(e, a) (_assertEquals(#a, e, a))
#define EQU_MSG(msg, e, a) (_assertEquals(msg, e, a, 1))
#define IS(e) (_assertTrue(#e, e))
#define IS_NOT(e) (_assertFalse(#e, e))
#define IS_MSG(msg, e) (_assertTrue(msg, e))
#define IS_NOT_MSG(msg, e) (_assertFalse(msg, e))
#define AR_EQU(e, a, n, p) (_assertArrayEquals(#a, e, a, n, p))
#define AR_EQU_MSG(m, e, a, n, p) (_assertArrayEquals(m, e, a, n, p))

#endif
