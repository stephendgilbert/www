/**
 *  @author Stephen Gilbert
 *  @date CS 150 Tests for LEC-07 (F'24)
 *  @file tests.cpp
 */

#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <fstream>
#include <random>
using namespace std;

#include "cs150check.h"

vector<string> testDataA = {
    "abc123xyz|123",
    "Chocolate|0",
    "5hoco1a1e|7",
    "5$$1;;1!!|7",
    "|0",
    "bz09napfqxie|9",
    "gepy|0",
    "0uiw5x2v8lx|15",
    "a|0",
    "7zh|7",
    "2xz86vr013h2s78c6j|187",
    "fpl|0",
    "8c|8",
    "04e68y2h02dx5h|81",
    "urce|0",
    "a5r8rfl|13",
    "r11v57d12x|80",
    "g|0",
    "wb4x|4",
    "4p|4",
    "415hz7n|422",
    "hdv00lb324eie|324",
    "vll2013s|2013",
    "h3pn6f291fh5l7v9i2i|323",
    "71f1mlz4247wb|4319",
    "k05485o27672o|33157",
    "xw55t|55",
    "ase06xj|6",
    "mjw69g9j3uxh|81",
    "yl39x|39",
};
vector<string> testDataB = {
    "aa11b33|44",
    "7 11|18",
    "a1234bb11|1245",
    "a22bbb3|25",
    "i3i110h9|122",
    "we69a9es6l449|533",
    "ut80k770|850",
    "3mqw7n81469|81479",
    "6227326n73g2|6227401",
    "4p5q4g49o7j0|69",
    "dhvj7y365ut85019|85391",
    "9y4h4|17",
    "rj4xubf2|6",
    "5vcpdx7053911|7053916",
    "93|93",
    "d36|36",
    "8|8",
    "69p2798|2867",
    "32rj05xorky3|40",
    "9aqu6gt1j6f4z2i7|35",
    "a70rg65h8duwchdnb15|158",
    "yh69m662|731",
    "9l65847y44|65900",
    "ln5g9|14",
    "hiez6ic3|9",
    "ws569o85oqwrp75om1|730",
    "9wz1d73277r8047|81334",
    "t93f2v8c721|824",
    "t5k2z2nov0i6|15",
};

int sum_nums(const string& str);

int runTests()
{
	srand(time(0));
	///////////// Begin a set of tests
	beginTests(); // test heading

    std::random_device rd;
    std::mt19937 g(rd());

    std::shuffle(testDataA.begin(), testDataA.end(), g);
    std::shuffle(testDataB.begin(), testDataB.end(), g);

	vector<string> tests;
	for (int i = 0; i < 8; i++)
	{
	    tests.push_back(testDataA.at(i));
	    tests.push_back(testDataB.at(i));
	}
	std::shuffle(tests.begin(), tests.end(), g);

    /////// Tests for focalLength - change refractiveIndex //////////////////////
	beginFunctionTest("sum_nums(\"str\")"); // function name

	for (const auto& e : tests)
	{
		auto mid = e.find('|');
		const string arg{e.substr(0, mid)};
		const int expected{std::stoi(e.substr(mid + 1))};
		string msg = "sum_nums(\"" + arg + "\")";
		try {
			EQU_MSG(msg, expected, sum_nums(arg));
		} catch (...) {
			failMsg(msg);
		}
	}

    endFunctionTest(); // end

    ///////// End all test runs /////////////////////////
    endTests();
    return 0;
}

