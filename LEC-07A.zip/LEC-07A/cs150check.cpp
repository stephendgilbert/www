/**
 * Basic unit tests for CS 150
 * @author Steve G.
 * @version Spring 2020
 * This is the implementation file.
 */
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stdexcept>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <vector>
#include <algorithm>

using namespace std;
string assignment = "LEC-07";

#include "cs150check.h"

/**
 * Global variables for scoring points.
 */
int possible = 0;
int fail = 0;
static const string UNDERLINE(70,'-');

static int allPossible = 0;
static int allFail = 0;

void _successReport(const string& msg)
{
    cerr << "   + " << msg << endl;
}

void _failReport(const string& msg, int points)
{
	cerr << "   X " << msg << endl;
	fail += points;
}

void failMsg(const string& msg, int points)
{
    possible += points;
    _failReport(msg, points);
}

void passMsg(const string& msg, int points)
{
    possible += points;
    _successReport(msg);
}

//////////// OVERLOADED VERSION OF ASSERT_EQUALS ///////////////////////
void _assertEquals(const string& msg, const string& expected, const string& actual, int points)
{
    possible += points;
    if (expected != actual)
    {
    	_failReportEquals(msg, expected, actual);
    }
    else
    	_successReport(msg + "->" + actual);
}

void _assertEquals(const string& msg, int expected, int actual, int points)
{
    possible += points;
    if (expected != actual)
    {
    	_failReportEquals(msg, expected, actual, points);
    }
    else
    	_successReport(msg);
}

void _assertEquals(const std::string& msg, double expected, double actual, double tolerance, int points)
{
    possible += points;
    double diff = abs(actual - expected);
    if (diff <= tolerance)
    {
    	_successReport(msg);
    }
    else
    {
    	_failReportEquals(msg, expected, actual, points);
    }
}

void _assertTrue(const std::string& msg, bool cond)
{
    possible++;
    if (!cond)
    {
    	_failReport(msg + " is false.");
    }
    else
    	_successReport(msg);
}

void _assertFalse(bool cond, const string& msg)
{
    possible++;
    if (cond)
    {
    	_failReport(msg + " should be false, but is true.");
    }
    else
    	_successReport(msg);
}

void beginTests(bool instructor)
{
    cerr << (instructor ? "INSTRUCTOR " : "student ")
        << "TESTING " << assignment << "--" << student << endl;
    cerr << UNDERLINE << endl;
    allPossible = allFail = 0;
}

void beginFunctionTest(const string& functionName)
{
	possible = fail = 0;
    cerr << "Checking function: " << functionName << " -------------------" << endl;
}

void endFunctionTest()
{
    cerr << UNDERLINE << endl << "  Tests passing "
        << (possible - fail) << "/" << possible
        << " ("
        << fixed << setprecision(0)
        << (static_cast<double>(possible - fail) / possible) * 100.0
        << "%)." << endl << endl;

    allPossible += possible;
    allFail += fail;
}

//BASE64 Encoding to upload the homework grade to the CS150 Console.
//
static const std::string base64_chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789+/";

std::string base64_encode(const char* bytes_to_encode, size_t in_len)
{
    std::string ret;
    int i = 0;
    int j = 0;
    unsigned char char_array_3[3];
    unsigned char char_array_4[4];

    while (in_len--)
    {
        char_array_3[i++] = *(bytes_to_encode++);
        if (i == 3)
        {
            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
            char_array_4[1] = static_cast<unsigned char>(((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4));
            char_array_4[2] = static_cast<unsigned char>(((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6));
            char_array_4[3] = char_array_3[2] & 0x3f;

            for (i = 0; (i < 4) ; i++)
                ret += base64_chars[char_array_4[i]];
            i = 0;
        }
    }

    if (i)
    {
        for (j = i; j < 3; j++)
            char_array_3[j] = '\0';

        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
        char_array_4[1] = static_cast<unsigned char>(((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4));
        char_array_4[2] = static_cast<unsigned char>(((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6));
        char_array_4[3] = char_array_3[2] & 0x3f;

        for (j = 0; (j < i + 1); j++)
            ret += base64_chars[char_array_4[j]];

        while ((i++ < 3))
            ret += '=';

    }

    return ret;

}

unsigned myhash(const std::string& str)
{
    unsigned hash = 5381;
    for (size_t i = 0; i < str.size(); ++i)
        hash = 33 * hash + (unsigned char)str[i];
    return hash;
}


void endTests(bool instructor)
{
	double percent = (static_cast<double>(allPossible - allFail) / allPossible) * 100.0;
    cerr << UNDERLINE << endl
        << (instructor ? "INSTRUCTOR TESTS " : "student TESTS ")
        << assignment << ":" << student << ": ALL TESTS -- PASS "
        << (allPossible - allFail) << "/" << allPossible
        << " ("
        << fixed << setprecision(0)
        << percent
        << "%)." << endl << UNDERLINE << endl;
    // if (instructor)
    // {
    //     ostringstream out;
    //     out << fixed << setprecision(2) << static_cast<unsigned>(time(0))
    //             << ":" << student << ":" << assignment << ":" << percent << "%";
    //     string coding = out.str();
    //     cerr << base64_encode(coding.c_str(), coding.length()) << endl;
    // }
}

//// Code from cs150io.hxx
void replaceAll(string& str, const std::string& from, const std::string& to)
{
    if(from.empty()) return;
    size_t start_pos = 0;
    while((start_pos = str.find(from, start_pos)) != string::npos)
    {
        str.replace(start_pos, from.length(), to);
        start_pos += to.length(); // In case 'to' contains 'from', like replacing 'x' with 'yx'
    }
}

vector<string> getData(const string& testFile)
{
    vector<string> tests;
    ifstream in;
    in.open(testFile.c_str());
    if (! in)
    {
        cerr << "Cannot find \"" << testFile << "\" with your input and output." << endl;
        return tests;
    }

    // Put test file into a vector
    string line;
    int testNo = 1;
    while (getline(in, line))
    {
        if (line.find('|') == string::npos)
        {
            cerr << " ! Warning: line " << testNo << " in test file is not properly formed. Skipped." << endl;
        }
        else
        {
            tests.push_back(line);
        }
        testNo++;
    }
    return tests;
}
/**
 * Runs tests based on a vector with input|expected output
 * @param vector to process
 * @return 0 for success, -1 for failure.
 */
int runIOTests(const vector<string>& tests, bool instructor)
{
    // Version 3 - Spring 2018, using vectors

    beginTests(instructor);

    // Now, lets run all of the tests
    int result = 0;
    for (const auto& test : tests)
    {
        string::size_type mid = test.find('|');
        string input = test.substr(0, mid);
        replaceAll(input, "\\n", "\n");
        string expected = test.substr(mid + 1);
        replaceAll(expected, "\\n", "\n");

        ostringstream sout;
        istringstream sin(input);

        try
        {
        	streambuf* oldIn = cin.rdbuf();
        	streambuf* oldOut = cout.rdbuf();
        	cin.rdbuf(sin.rdbuf());
        	cout.rdbuf(sout.rdbuf());
            result = run();
            cin.rdbuf(oldIn);
            cout.rdbuf(oldOut);
        }
        catch (exception& e)
        {
            cerr << " X CRASH for input " << input << ": " << e.what() << endl;
            possible++;
            fail++;
            continue;
        }

        string actual = sout.str();
        string::size_type beg = actual.find('[');
        string::size_type end = actual.find(']');

        if (beg == string::npos || end == string::npos || beg >= end)
        {
            cerr << " X Cannot find output inside [] for " << input << ". Cannot run this test."  << endl;
            possible++;
            fail++;
            continue;
        }
        else
        {
            actual = actual.substr(beg + 1, end - beg - 1);
            _assertEquals("Input of " + input, expected, actual);
        }
    }
    allPossible = possible;
    allFail = fail;

    endTests(instructor);

    return result;
}

/**
 * Main file for all testing and regular running.
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char * argv[])
{
    srand(time(0));
	if (argc == 2)
	{
	    string arg(argv[1]);
		if (arg == "-t")
		    return runTests();
		else
		    return run();
	}
	else
	{
		return run();
	}
}

