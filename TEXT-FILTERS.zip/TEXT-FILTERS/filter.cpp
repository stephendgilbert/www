// The basic text filter for CS 150
#include <iostream>
using namespace std;

int main()
{
    char ch;
    while (cin.get(ch))
        cout.put(ch);
}
