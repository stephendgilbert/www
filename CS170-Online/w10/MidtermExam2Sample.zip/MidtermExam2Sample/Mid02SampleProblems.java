/**
 * Complete the methods in this class
 */
public class Mid02SampleProblems
{
    /**
     * 1. Basic Logic) Write the method: lastDigit().
     *
     * Given three int parameters, a b c, return true if two or more of
     * them have the same rightmost digit. All parameters are
     * non-negative. Note: the % "mod" operator computes the remainder,
     * e.g. 17 % 10 is 7.
     *
     * lastDigit(23, 19, 13) returns true
     * lastDigit(23, 19, 12) returns false
     * lastDigit(23, 19, 3) returns true
     *
     * @param a the first integer
     * @param b the second integer
     * @param c third integer
     *
     * @return true if two or more have the same right-most digit
     */



    /**
     * 2. Using if and else) Write the method caughtSpeeding()
     *
     * You are driving a little too fast, and a police officer stops
     * you. Write code to compute the result, encoded as an int: no ticket=0,
     * small ticket=1, big ticket=2. If speed is 60 or less, the result is 0.
     * If speed is between 61 and 80 inclusive, the result is 1.
     * If speed is 81 or more, the result is 2. Unless it is your birthday --
     * on that day, your speed can be 5 higher in all cases.
     *
     * caughtSpeeding(60, false) returns 0
     * caughtSpeeding(65, false) returns 1
     * caughtSpeeding(65, true) returns 0
     *
     * @param speed the speed you are driving.
     * @param isBirthday true if today is your birthday
     * @return the values 0(no ticket), 1(small ticket), or 2(big ticket)
     */



    /**
     * 3. A simple loop problem) Write the method stringBits().
     *
     * Given a string, return a new string made of every other char
     * starting with the first, so "Hello" yields "Hlo".
     *
     * stringBits("Hello") returns "Hlo"
     * stringBits("Hi") returns "H"
     * stringBits("HiHiHi") returns "HHH"
     *
     * @param str the String to process
     * @return the processed String.
     */


    /**
     *  4. A more difficult loop problem) Write the method prefixAgain().
     *
     *  Given a string, consider the prefix string made of the first
     *  N chars of the string str. Does that prefix string appear somewhere
     *  else in the string? You can assume that the string is not empty and
     *  that N is in the range 1..str.length().
     *
     *  prefixAgain("abXYabc", 1) returns true
     *  prefixAgain("abXYabc", 2) returns true
     *  prefixAgain("abXYabc", 3) returns false
     *
     *   @param str the String to examine.
     *   @param n the length of the substring to search for
     */



    /**
     * You may test your methods here. Use the instance variable
     * named obj to call your methods.
     * @param args the command-line arguments.
     */
    public static void main(String[] args)
    {
        Mid02SampleProblems obj = new Mid02SampleProblems();

        // Use obj to call and test your methods.

    }


}
