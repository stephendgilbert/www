import static net.sf.webcat.ReflectionSupport.*;
import net.sf.webcat.annotations.*;
import java.lang.reflect.*;
import java.util.*;
import static junit.framework.Assert.*;

/**
 *  Tests the CS 170 Student class.
 *  Midterm Exam 1 Version B: the Employee Class
 *
 *  @author  Stephen Gilbert
 *  @version Spring 2008
 */
public class StudentTest extends junit.framework.TestCase
{
    private Class thisClass;
    private Field[] fields;
    private Constructor[] constructors;
    private ArrayList<String> fieldNames = new ArrayList<String>();

    /**
     * Checks the type and other items.
     */
    public StudentTest()
    {
        try {
            thisClass = Class.forName("Student");

            fields = thisClass.getDeclaredFields();
            for (int i = 0; i < fields.length; i++) {
                fieldNames.add(fields[i].getName());
            }

            constructors = thisClass.getDeclaredConstructors();
        }
        catch (ClassNotFoundException e) {
            /* Nothing to catch */
        }
    }

    /**
     * Make sure that the class exists.
     */
    @Hint("You don't seem to have an Student class")
    public void testClassStudentExists()
    {
        assertNotNull("No Student class", thisClass);
    }

    /**
     * Make sure that the correct number of fields are declared.
     */
    @Hint("You seem to have more (or fewer) fields defined than specified.")
    public void testThatClassHasCorrectNumberOfFields()
    {
        assertEquals("You should have 5 fields", 5, fields.length);
    }

    /**
     * Testing the CREATOR field.
     * Does CREATOR exist?
     */
    @ScoringWeight(.5)
    public void testCREATORExists() {
        assertFieldExists("CREATOR");
    }

    /**
     * Is the field public?
     */
    @ScoringWeight(.5)
    public void testCREATORIsPublic() {
        assertIsPublic(getField("CREATOR"));
    }

    /**
     * Is the field static?
     */
    @ScoringWeight(.5)
    public void testCREATORIsStatic() {
        assertIsStatic(getField("CREATOR"));
    }

    /**
     * Is the field final?
     */
    @ScoringWeight(.5)
    public void testCREATORIsFinal() {
        assertIsFinal(getField("CREATOR"));
    }

    /**
     * Is the field type String?
     */
    @ScoringWeight(.5)
    public void testCREATORIsString() {
        assertIsType(getField("CREATOR"), "String");
    }

    /**
     * Testing the lastName field.
     * Does lastName exist?
     */
    @ScoringWeight(.5)
    public void testLastNameExists() {
        assertFieldExists("lastName");
    }

    /**
     * Is the field private?
     */
    @ScoringWeight(.5)
    public void testLastNameIsPrivate() {
        assertIsPrivate(getField("lastName"));
    }

    /**
     * Is the field type String?
     */
    @ScoringWeight(.5)
    public void testLastNameIsString() {
        assertIsType(getField("lastName"), "String");
    }

    /**
     * Testing the firstName field.
     * Does firstName exist?
     */
    @ScoringWeight(.5)
    public void testFirstNameExists() {
        assertFieldExists("firstName");
    }

    /**
     * Is the field private?
     */
    @ScoringWeight(.5)
    public void testFirstNameIsPrivate() {
        assertIsPrivate(getField("firstName"));
    }

    /**
     * Is the field type String?
     */
    @ScoringWeight(.5)
    public void testFirstNameIsString() {
        assertIsType(getField("firstName"), "String");
    }

    /**
     * Testing the scores field.
     * Does scores exist?
     */
    @ScoringWeight(.5)
    public void testScoresExists() {
        assertFieldExists("scores");
    }

    /**
     * Is the field private?
     */
    @ScoringWeight(.5)
    public void testScoresIsPrivate() {
        assertIsPrivate(getField("scores"));
    }

    /**
     * Is the field type int?
     */
    @ScoringWeight(.5)
    public void testScoresIsInt() {
        assertIsType(getField("scores"), "int");
    }

    /**
     * Testing the numQuizzes field.
     * Does numQuizzes exist?
     */
    @ScoringWeight(.5)
    public void testNumQuizzesExists() {
        assertFieldExists("numQuizzes");
    }

    /**
     * Is the field private?
     */
    @ScoringWeight(.5)
    public void testNumQuizzesIsPrivate() {
        assertIsPrivate(getField("numQuizzes"));
    }

    /**
     * Is the field type int?
     */
    @ScoringWeight(.5)
    public void testNumQuizzesIsInt() {
        assertIsType(getField("numQuizzes"), "int");
    }

    /**
     *  Private methods for testing fields.
     *  Returns field given a name.
     */
    private Field getField(String fname) {
        int pos = fieldNames.indexOf(fname);
        return (pos < 0) ? null : fields[pos];
    }

    /**
     * Checks if the field is the correct type.
     */
    private void assertIsType(Field f, String desiredType) {
        assertTrue("Field " + f.getType().getSimpleName() +
                " is not of type " + desiredType,
            f.getType().getSimpleName().equals(desiredType));
    }

    /**
     * Asserts that the field is exists.
     */
    private void assertFieldExists(String fname) {
        assertTrue("Field " + fname + " does not exist.",
            fieldNames.contains(fname));
    }

    /**
     * Asserts that the field is private.
     */
    private void assertIsPrivate(Field f) {
        assertTrue("Field " + f.getName() + " is not private.",
            Modifier.isPrivate(f.getModifiers()));
    }

    /**
     * Asserts that the field is public.
     */
    private void assertIsPublic(Field f) {
        assertTrue("Field " + f.getName() + " is not public.",
            Modifier.isPublic(f.getModifiers()));
    }

    /**
     * Asserts that the field is static.
     */
    private void assertIsStatic(Field f) {
        assertTrue("Field " + f.getName() + " is not static.",
            Modifier.isStatic(f.getModifiers()));
    }

    /**
     * Asserts that the field is final.
     */
    private void assertIsFinal(Field f) {
        assertTrue("Field " + f.getName() + " is not a constant.",
            Modifier.isFinal(f.getModifiers()));
    }

    // =====================================================
    // DEFINE CONSTRUCTOR AND METHOD STRUCTURE
    // =====================================================
    /**
     * Test to make sure that exactly one constructor is defined.
     */
    public void testConstructorDefined() {
        assertTrue("You must define exactly one constructor.",
            constructors.length == 1);
    }

    /**
     * Make sure constructor uses the correct number of arguments.
     */
    public void testNumberOfConstructorParameters() {
        Constructor c = constructors[0];
        Class[] params = c.getParameterTypes();
        assertTrue("Your constructor must take two parameters.",
            params.length == 2);
    }

    /**
     * Make sure that the constructor uses the correct type of arguments.
     */
    public void testTypeOfConstructionParameters() {
        Constructor c = constructors[0];
        Class[] params = c.getParameterTypes();
        assertTrue("Construction parameters are the wrong type or order.",
            params[0].getSimpleName().equals("String") &&
            params[1].getSimpleName().equals("String"));
    }

    /**
     * Make sure that the getName method has the correct signature..
     */
    public void testGetNameDefinedCorrectly() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        String name = invoke(obj, String.class, "getName", params);
    }

    /**
     * Make sure that the getTotalScores method has the correct signature..
     */
    public void testGetTotalScoresDefinedCorrectly() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        int score = invoke(obj, Integer.class, "getTotalScores", params);
    }

    /**
     * Make sure that the getAverageScore method has the correct signature..
     */
    public void testGetAverageScoreDefinedCorrectly() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "addQuiz", 75);
        double avg = invoke(obj, Integer.class, "getTotalScores", params);
    }

    /**
     * Make sure that the addQuiz method has the correct signature..
     */
    public void testAddQuizDefinedCorrectly() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "addQuiz", 75);
    }

    /**
     * Make sure that the setName method is defined correctly.
     */
    public void testSetNameDefinedCorrectly() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "setName", "Baggins,Bilbo");
    }

    /**
    // ======================================================
    // CLASS BEHAVIOR HERE
    // ======================================================

    /**
     * Make sure that the constructor initializes name correctly.
     */
    @ScoringWeight(2.0)
    public void testConstructorName() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        String name = invoke(obj, String.class, "getName", params);

        assertEquals("After construction, name should be Ticklme Elmo.",
            "Ticklme Elmo", name);
    }

    /**
     * Make sure that the constructor initializes score correctly.
     */
    @ScoringWeight(2.0)
    public void testConstructorScores() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        int score = invoke(obj, Integer.class, "getTotalScores", params);

        assertEquals("After construction, score should be 0.", 0, score);
    }

    /**
     * Make sure that addQuiz initializes score correctly.
     */
    @ScoringWeight(2.0)
    public void testAddQuizSingleQuiz() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "addQuiz", 75);
        int score = invoke(obj, Integer.class, "getTotalScores", params);

        assertEquals("After adding 1 quiz, score should be 75.", 75, score);
    }

    /**
     * Make sure that addQuiz initializes score correctly.
     * Multiple scores, not one.
     */
    @ScoringWeight(2.0)
    public void testAddQuizMultipleQuizzes() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "addQuiz", 75);
        invoke(obj, "addQuiz", 85);
        int score = invoke(obj, Integer.class, "getTotalScores", params);

        assertEquals("After adding 2 quizzes, score should be 160.", 160, score);
    }

    /**
     * Make sure that getAverageScore works correctly.
     * No quizzes. Should return NAN.
     */
    @ScoringWeight(2.0)
    public void testGetAverageScoreNoQuiz() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        double avg = invoke(obj, Double.class, "getAverageScore", params);

        assertEquals("With no quizzes, average should be " + (0.0/0.0) + ".", (0.0/0.0), avg);
    }
    
    /**
     * Make sure that getAverageScore works correctly.
     * Single quiz.
     */
    @ScoringWeight(2.0)
    public void testGetAverageScoreSingleQuiz() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "addQuiz", 75);
        double avg = invoke(obj, Double.class, "getAverageScore", params);

        assertEquals("After adding 1 quiz, average should be 75.", 75.0, avg);
    }

    /**
     * Make sure that getAverageScore works correctly.
     * Multiple quizzes.
     */
    @ScoringWeight(2.0)
    public void testGetAverageScoreMultipleQuizzes() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "addQuiz", 75);
        invoke(obj, "addQuiz", 85);
        double avg = invoke(obj, Double.class, "getAverageScore", params);

        assertEquals("After adding 2 quizzes, average should be 80.", 80.0, avg);
    }


    /**
     * Make sure that the setName method works correctly.
     * Passing a simple name with no space.
     */
    @ScoringWeight(2.0)
    public void testSetNameNoSpaces() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "setName", "Baggins,Bilbo");
        String name = invoke(obj, String.class, "getName", params);

        assertEquals("In setName(), name should be \"Bilbo Baggins\", not \"" + name + "\"",
            "Bilbo Baggins", name);
    }

    /**
     * Make sure that the setName method works correctly.
     * Passing a simple name with one space after the comma.
     */
    @ScoringWeight(2.0)
    public void testSetNameOneSpace() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "setName", "Bond, James");
        String name = invoke(obj, String.class, "getName", params);

        assertEquals("In setName(), name should be \"James Bond\", not \"" + name + "\"",
            "James Bond", name);
    }

    /**
     * Make sure that the setName method works correctly.
     * Passing a name with multiple spaces.
     */
    @ScoringWeight(2.0)
    public void testSetNameMultipleSpaces() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "setName", "  Sparrow,   Captain Jack  ");
        String name = invoke(obj, String.class, "getName", params);

        assertEquals("After setName(), name should be \"Captain Jack Sparrow\", not \"" + name + "\"",
            "Captain Jack Sparrow", name);
    }

    /**
     * Make sure that the toString method works correctly.
     * Line length.
     */
    @ScoringWeight(2.0)
    public void test_mToStringLineLength() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        String s = invoke(obj, String.class, "toString", params);
        String[] lines = s.split("\n");

        assertTrue("Output should be on three lines.", lines.length == 3);
    }

    /**
     * Make sure that the toString method works correctly.
     * Line 1.
     */
    @ScoringWeight(2.0)
    public void test_mToStringLineOne() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        String s = invoke(obj, String.class, "toString", params);
        String[] lines = s.split("\n");

        assertEquals("toString() 1 s/b: \"Student: Elmo, Ticklme\" not \"" + lines[0] + "\"",
            "Student: Elmo, Ticklme", lines[0]);
    }

    /**
     * Make sure that the toString method works correctly.
     * Line 2.
     */
    @ScoringWeight(2.0)
    public void test_mToStringLineTwo() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "addQuiz", 50);
        invoke(obj, "addQuiz", 60);
        invoke(obj, "addQuiz", 70);
        invoke(obj, "addQuiz", 80);

        String s = invoke(obj, String.class, "toString", params);
        String[] lines = s.split("\n");

        assertEquals("toString() 2 s/b: \"Points: 260 points from 4 quizzes\" not \"" + lines[1] + "\"",
            "Points: 260 points from 4 quizzes", lines[1]);

        invoke(obj, "addQuiz", 40);
        s = invoke(obj, String.class, "toString", params);
        lines = s.split("\n");

        assertEquals("toString() 2 s/b: \"Points: 300 points from 5 quizzes\" not \"" + lines[1] + "\"",
            "Points: 300 points from 5 quizzes", lines[1]);
    }

    /**
     * Make sure that the toString method works correctly.
     * Line 3.
     */
    @ScoringWeight(2.0)
    public void test_mToStringLineThree() {
        Object obj = create("Student", "Elmo", "Ticklme");
        Object[] params = {};

        invoke(obj, "addQuiz", 50);
        invoke(obj, "addQuiz", 60);

        String s = invoke(obj, String.class, "toString", params);
        String[] lines = s.split("\n");

        assertEquals("toString() 3 s/b: \"Average Score: 55.000\" not \"" + lines[2] + "\"",
            "Average Score: 55.000", lines[2]);

        invoke(obj, "addQuiz", 51);
        s = invoke(obj, String.class, "toString", params);
        lines = s.split("\n");

        assertEquals("toString() 3 s/b: \"Average Score: 53.667\" not \"" + lines[2] + "\"",
            "Average Score: 53.667", lines[2]);
    }
}
