/**
 * 	Rank.java: playing card ranks.
 *
 *	@author Stephen Dean Gilbert
 *	@version Mar 28, 2008	 
 */

public enum Rank
{
    /**
     * Values for each rank.
     */
    TWO, THREE, FOUR, FIVE, SIX, SEVEN, 
    EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE;
    
}
