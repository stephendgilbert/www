/**
 *  InsertArray.java
 *  
 *  Adding items to an array in sorted order
 *  
 *  @author Stephen Gilbert
 *  @version 3.0, Java 6 version, 2008
*/
import java.util.*;

public class InsertArray
{
    public static void main(String[] args)
    {
        // Scanner for input
        Scanner scan = new Scanner(System.in);

        // Here's our array along with capacity and size
        double[] ar = new double[100];
        int capacity = ar.length;
        int size = 0;

        // Prompt the user for input
        System.out.println("Enter up to " + capacity +
                           " positive real numbers.");
        System.out.println("Enter 0 or a negative number to quit.");
        
        while (size < capacity)
        {
            // Get a number and check the sentinel value.
            double num = scan.nextDouble();
            if (num <= 0)
                break;

            //  Exercise 18.12
            //  Got a valid number. Where should we put it?
            //  Loop through and find the first number that's
            //  larger than the number input. Store it in "pos"
            
            
            //  Exercise 18.13
            //  Move the array elements to make room for
            //  the new number. Note that you must move the
            //  numbers starting at the end of the array.
            //  Use size to tell you where you can move.

            
            // Put the current element into its position

            
            // Increment the size
            size++;
        }

        // 8. Display results
        System.out.print("ar = {");
        if (size == 0)
        {
            System.out.println("}");
        }
        else
        {
            for (int i = 0; i < size -1; i++)
                System.out.print(ar[i] + ", ");
            System.out.println(ar[size-1] + "}");
        }
    }
}
