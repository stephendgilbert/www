import acm.program.*;
import acm.graphics.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Using an array to represent a Deck of cards.
 * 
 * @author (place your name here)
 * @version (place the date here)
 */

public class CardDeckArray extends GraphicsProgram
{
    // Cards and decks
    private int cardsRemaining;
    
    // 1. Create variable that can refer to an array 
    //    of Card objects (Exercise 18.2)
    
    
    /**
     * The deck pile just shows the back of the deck.
     * Click the deck to deal a card.
     */
    private GImage deckPile;

    /**
     * The cardPile is the container that will hold the
     * cards as they are dealt on the table
     */
    private GCompound cardPile = new GCompound();
    
    
    /**
     * The newDeck() method.
     * Return a deck of 52 cards
     * 
     * @return an array of cards, un-shuffled.
     * Exercise 18.3.
     */

    
    /**
     *  shuffle(): shuffle a deck of cards.
     *  @param a the array of Card objects.
     *  Exercise 18.6 part A
     */
    

 
    /**
     * Handle the button clicks
     */
    public void actionPerformed(ActionEvent e)
    {
        Object clicked = e.getSource();
        
        // Adding a new deck to the table
        if (clicked == newDeckBtn)
        {
            // 1. Call newDeck() method and assign to deck 
            //    variable. (Exercise 18.4)
            
            
            // 2. Set the cards remaining to the length of 
            //    the deck. 
            
            
            showStatus();

            if (deckPile == null)
            {
                deckPile = new GImage("cards/b.gif");
                GCanvas c = this.getGCanvas();
                int x = c.getWidth() / 2 - (int) (deckPile.getWidth()) - 10;
                int y = c.getHeight() / 2 - ((int) (deckPile.getHeight()) / 2);
                
                add(deckPile, x, y);
                cardPile.removeAll();
                add(cardPile, x + deckPile.getWidth() + 20, y);
            }
            
            newDeckBtn.setEnabled(false);
            shuffleDeckBtn.setEnabled(true);
        }
        else if (clicked == shuffleDeckBtn)
        {
            // Shuffle the cards
            // Exercise 18.6 part B
        }
    }
    
    
    /**
     * Deal a card from the top of the deck.
     */
    public void mouseClicked(MouseEvent e)
    {
        // Get the mouse location
        int x = e.getX();
        int y = e.getY();
        
        // Find the object under the mouse click
        GObject obj = getElementAt(x, y);
        
        // Only deal a card if clicking on the deck pile 
        if (obj == deckPile)
        {
            // 1. The current card is the length of the deck
            //    minus the number of cards remaining.
            // Exercise 18.5.
            
            
            // 2. Flip the current card in the deck face up
            //    and throw it onto the cardPile
            //    (Use the cardPile add() method)
            
            
            
            // Decrement the number of cards left and show status
            cardsRemaining--;
            showStatus();

            // If we've dealt all the cards, remove the 
            // deck pile from the table.
            if (cardsRemaining == 0)
            {
                remove(deckPile);
                deckPile = null;
                newDeckBtn.setEnabled(true);
            }           
        }
    }
    
   
    /**
     * The standard Java entry point. DON'T MODIFY THIS METHOD.
     */
    public static void main(String[] args)
    {
        new CardDeckArray().start(args);
    }

    /**
     * Initialize the user interface
     */
    public void init()
    {
        // Set the table color to a dark green
        setBackground(new Color(0, 128, 0));
        
        // Initialize the GUI
        newDeckBtn = new JButton("New Deck");
        shuffleDeckBtn = new JButton("Shuffle");
        statusLbl = new JLabel("Welcome to CardDeckDemo");
        
        shuffleDeckBtn.setEnabled(false);

        add(newDeckBtn, SOUTH);
        add(shuffleDeckBtn, SOUTH);
        add(statusLbl, NORTH);

        addActionListeners();
        addMouseListeners();
    }

    /**
     *  Show the number of cards remaining. 
     */
    public void showStatus()
    {
        statusLbl.setText("Cards Left: " + cardsRemaining);
    }

    /**
     * User interface controls
     */
    private JButton newDeckBtn;         // Adding a new deck
    private JButton shuffleDeckBtn;     // Shuffling the deck
    private JLabel statusLbl;           // Display the status

    public static final int APPLICATION_WIDTH = 350;
    public static final int APPLICATION_HEIGHT = 250;
}
