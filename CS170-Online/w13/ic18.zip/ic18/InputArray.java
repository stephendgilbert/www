/**
 *  InputArray.java
 *  CS 170 Exercise 2008
 *  
 *  Adding items to a "partially filled" array
 *
 *  @author Stephen Gilbert
 *  @version 2.0, Java 5 version, Nov 10, 2006
*/
import java.util.*;

public class InputArray
{
    public static void main(String[] args)
    {
        // Scanner for input
        Scanner scan = new Scanner(System.in);

        // 1. Create an array of 100 doubles named ar
        //    Create two int variables for capacity and size
        // Exercise 18.11

        
        // Get the input from the user
        System.out.println("Enter up to " + capacity +
                           " positive real numbers.");
        System.out.println("Enter 0 or a negative number to quit.");
        
        while (size < capacity)
        {
            // Read a number
            double num = scan.nextDouble();

            // If the user wants to exit, then leave
            if (num <= 0)
                break;

            // 2. Otherwise store the number at size
            

            // 3. Increment the size
        }

        // 8. Display results
        System.out.print("ar = {");
        if (size == 0)
        {
            System.out.println("}");
        }
        else
        {
            for (int i = 0; i < size -1; i++)
                System.out.print(ar[i] + ", ");
            System.out.println(ar[size-1] + "}");
        }
    }
}
