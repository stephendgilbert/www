/**
 *  ToolBar.java
 *  Illustrates using arrays of object variables
 *  
 * @author Stephen Gilbert
 * @version 2.0, 2008
 */
import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class ToolBar extends Applet
{
    // Attributes
    private String slogan = "CS 170 : Java, Java Java!!!";
    private Button[] toolBar = new Button[5];

    public void init()
    {
        // 1. Toolbar Panel
        Panel p = new Panel();
        p.setLayout(new FlowLayout(FlowLayout.LEFT));
        p.setBackground(Color.lightGray);

        // 2. Create the toolBar Buttons
        String[] captions =
            { "Red", "Blue", "Green", "Yellow", "Black" };

        // 3. Create an object to handle events
        ColorSelector cs = new ColorSelector();

        // 4. Create each button
        for (int i = 0; i < toolBar.length; i++)
        {
            toolBar[i] = new Button(captions[i]);
            toolBar[i].addActionListener(cs);
            p.add(toolBar[i]);
        }

        // 5. Add the Panel to the top of the applet
        setLayout(new BorderLayout());
        add(p, "North");
    }

    /**
     * Paint the slogan on the the screen
     */
    public void paint(Graphics g)
    {
        int height = getSize().height;
        int width = getSize().width;

        g.setFont(new Font("Serif", Font.BOLD + Font.ITALIC, 36));
        FontMetrics fm = g.getFontMetrics();
        int strWidth = fm.stringWidth(slogan);

        int x = width / 2 - (strWidth / 2);
        int y = height / 2 + (fm.getHeight() / 2);

        g.setColor(Color.white);
        g.drawString(slogan, x, y);
    }

    /**
     * Handle the clicks on the different buttons in the toolBar array
     */
    class ColorSelector implements ActionListener
    {
        public void actionPerformed(ActionEvent ae)
        {
            // 1. Retrieve source of click
            Object obj = ae.getSource();

            // 2. Match it with toolBar Button
            int clicked;
            for (clicked = 0; clicked < toolBar.length; clicked++)
            {
                if (obj == toolBar[clicked]) break;
            }

            // 3. Take action based upon Button pressed
            switch (clicked)
            {
                case 0:
                    setBackground(Color.red);
                    break;
                case 1:
                    setBackground(Color.blue);
                    break;
                case 2:
                    setBackground(Color.green);
                    break;
                case 3:
                    setBackground(Color.yellow);
                    break;
                case 4:
                    setBackground(Color.black);
                    break;
            }
            repaint();
        }
    }
}
