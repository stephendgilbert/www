import static org.junit.Assert.*;

import org.junit.Test;

/**
 *  TestRotateLeft.java: Tests the rotateLeft method.
 *  CS 170 Array practice exercises.
 *
 *  @author Stephen Dean Gilbert
 *  @version Apr 27, 2008
 */

public class TestRotateLeft
{

    public boolean areEqual(int[] a, int[] b)
    {
        if (a.length != b.length) return false;
        for (int i = 0; i < a.length; i++)
            if (a[i] != b[i])
                return false;
        return true;
    }
    
    /**
     * Test methods for rotateLeft.      
     */
    @Test
    public void testRotateLeft6_2_5_3()
    {
        ArrayPracticeExercises obj = new ArrayPracticeExercises();
        
        int[] a = {6, 2, 5, 3};
        int[] b = {2, 5, 3, 6};
        obj.rotateLeft(a);
        
        assertTrue(areEqual(a, b));
    }

    @Test
    public void testRotateLeft1_2()
    {
        ArrayPracticeExercises obj = new ArrayPracticeExercises();
        
        int[] a = {1,2};
        int[] b = {2,1};
        obj.rotateLeft(a);
        
        assertTrue(areEqual(a, b));
    }

    @Test
    public void testRotateLeft1()
    {
        ArrayPracticeExercises obj = new ArrayPracticeExercises();
        
        int[] a = {1};
        int[] b = {1};
        obj.rotateLeft(a);
        
        assertTrue(areEqual(a, b));
    }

    @Test
    public void testRotateLeftEmpty()
    {
        ArrayPracticeExercises obj = new ArrayPracticeExercises();
        
        int[] a = {};
        int[] b = {};
        obj.rotateLeft(a);
        
        assertTrue(areEqual(a, b));
    }

    @Test
    public void testRotateLeft1_1_2_2_4()
    {
        ArrayPracticeExercises obj = new ArrayPracticeExercises();
        
        int[] a = {1,1,2,2,4};
        int[] b = {1,2,2,4,1};
        obj.rotateLeft(a);
        
        assertTrue(areEqual(a, b));
    }

    @Test
    public void testRotateLeft1_1_1()
    {
        ArrayPracticeExercises obj = new ArrayPracticeExercises();
        
        int[] a = {1,1,1};
        int[] b = {1,1,1};
        obj.rotateLeft(a);
        
        assertTrue(areEqual(a, b));
    }

    @Test
    public void testRotateLeft1_2_3()
    {
        ArrayPracticeExercises obj = new ArrayPracticeExercises();
        
        int[] a = {1, 2, 3};
        int[] b = {2, 3, 1};
        obj.rotateLeft(a);
        
        assertTrue(areEqual(a, b));
    }
}
