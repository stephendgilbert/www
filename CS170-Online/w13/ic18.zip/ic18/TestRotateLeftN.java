import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;

/**
 *  TestRotateLeftN.java: Tests the rotateLeftN method.
 *  CS 170 Array practice exercises.
 *
 *  @author Stephen Dean Gilbert
 *  @version Apr 27, 2008
 */

public class TestRotateLeftN
{
    private  ArrayPracticeExercises obj;
    
    /**
     * Initialize the ArrayPracticeExercises object.
     */
    @Before
    public void setUp()
    {
        obj = new ArrayPracticeExercises();
    }

    public boolean areEqual(int[] a, int[] b)
    {
        if (a.length != b.length) return false;
        for (int i = 0; i < a.length; i++)
            if (a[i] != b[i])
                return false;
        return true;
    }
    
    /**
     * Test methods for rotateLeftN.      
     */
    @Test
    public void testRotateLeft6_2_5_3_One()
    {
        int[] a = {6, 2, 5, 3};
        int[] b = {2, 5, 3, 6};
        obj.rotateLeftN(a, 1);
        
        assertTrue(areEqual(a, b));
    }

    @Test
    public void testRotateLeft6_2_5_3_Two()
    {
        int[] a = {6, 2, 5, 3};
        int[] b = {5, 3, 6, 2};
        obj.rotateLeftN(a, 2);
        
        assertTrue(areEqual(a, b));
    }
    
    @Test
    public void testRotateLeft6_2_5_3_Three()
    {
        int[] a = {6, 2, 5, 3};
        int[] b = {3, 6, 2, 5};
        obj.rotateLeftN(a, 3);
        
        assertTrue(areEqual(a, b));
    }

    @Test
    public void testRotateLeft6_2_5_3_Four()
    {
        int[] a = {6, 2, 5, 3};
        int[] b = {6, 2, 5, 3};
        obj.shiftLeftN(a, 4);
        
        assertTrue(areEqual(a, b));
    }
}
