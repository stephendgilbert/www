/**
 *  Suit.java: Playing-card suits.
 *
 *  @author Stephen Dean Gilbert
 *  @version Mar 28, 2008
 */

public enum Suit
{
    CLUBS, SPADES, DIAMONDS, HEARTS;
}
