import java.util.Scanner;

/**
 * Array practice exercises for CS 170
 * @author Stephen Gilbert
 * @version 2008
 */
public class ArrayPracticeExercises
{
    /**
     * rotateLeft: modifies the int array so that all elements
     * are "left shifted" by one, so {6,2,5,3} becomes {2,5,3,6}.
     * 
     * @param a the int array to modify.
     * Exercise 18.8-A
     */
    
    /**
     * rotateLeftN: modifies the int array so that all elements
     * are "left shifted" by N, so {6,2,5,3}, 2 becomes {5,3,6,2}.
     * 
     * @param a the int array to modify.
     * @param n the number of times to shift left.
     * Exercise 18.8-B
     */

    
    /**
     * Initialize and reverse a character array.
     * Exercise 18.7
     */
    public static void main(String[] args)
    {
        // Given these declarations
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a line of text: ");
        String inStr = scan.nextLine();
        char[] phrase = new char[inStr.length()];
        
        // 1. Fill the array phrase with the characters from inStr
        
        // 2. Reverse the characters by swapping the first with 
        //    the last until all are swapped.
        
        System.out.println("Original: " + inStr);
        System.out.print("Reversed: ");
        // 3. Print the array
        
    }
    
}
