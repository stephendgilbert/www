/**
 *  ExtremeValues.java
 *  CS 170 Exercise 2008
 *  Illustrates finding the extreme values in an array
 *
 *  @author Stephen Gilbert
 *  @version 3.0, April 2008
 */
import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.text.*;

public class ExtremeValues extends Applet implements ActionListener
{
    public void actionPerformed(ActionEvent ae)
    {
        // Here's our array
        double[] ar = new double[100];
        int len = ar.length;

        // Initialize with Math.random()
        for (int idx = 0; idx < len; idx++)
        {
            ar[idx] = Math.random() * len;
        }

        // Calculate sum and average
        double sum = 0.0, avg;
        for (double element: ar)
            sum += element;
        avg = sum / len;

        // Locate the largest and smallest values
        // Exercise 18.10
        //
        // 1. Store the first element in largest and smallest
        // 2. Loop through elements from 1 to len-1
        // 3. If current element is smaller than smallest, 
        //    assign current element to smallest. Do the
        //    same thing for largest.

        // Display results
        // Uncomment code below when variables are defined.
        /*
        output.setText("Sum = " + dfmt.format(sum) + ", Avg = "
                + dfmt.format(avg) + ", Largest = "
                + dfmt.format(largest) + ", Smallest = "
                + dfmt.format(smallest));
        */
    }
    
    /**
     * User interface controls and setup.
     */
    private Button calcIt = new Button("Process an Array");
    private Label output = new Label("", Label.CENTER);

    // Format decimal & percentages
    private NumberFormat dfmt = NumberFormat.getNumberInstance();

    public void init()
    {
        setLayout(new BorderLayout());
        add(output, "North");
        add(calcIt, "South");
        calcIt.addActionListener(this);
    }
}
