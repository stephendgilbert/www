import acm.graphics.*;

/**
 * Card.java: represents a playing card. Each card will have a suit and a rank.
 * 
 * @author Stephen Dean Gilbert
 * @version Mar 28, 2008
 */

public class Card extends GImage
{
    /**
     * Suit of this card.
     */
    private Suit suit;

    /**
     * Rank of this card.
     */
    private Rank rank;

    /**
     * True if card is face down (back showing).
     */
    private boolean isFaceDown = true;

    /**
     * Construct a Card using Rank and Suit.
     * @param r the Rank of this card.
     * @param s the Suit of this card.
     */
    public Card(Rank r, Suit s)
    {
        super("cards/b.gif");
        rank = r;
        suit = s;
    }

    /**
     * Returns the suit.
     * 
     * @return the suit.
     */
    public Suit getSuit()
    {
        return suit;
    }

    /**
     * Returns the rank.
     * 
     * @return the rank
     */
    public Rank getRank()
    {
        return rank;
    }

    /**
     * True if the card is face down.
     * 
     * @return the isFaceDown
     */
    public boolean isFaceDown()
    {
        return isFaceDown;
    }

    /**
     * Calculates the file-name for this card.
     * @return the calculated file name.
     */
    private String getFileName()
    {
        return "cards/" + rankSymbol() + suitSymbol() + ".gif";
    }

    /**
     * Calculates the rank symbol using a switch.
     * @return the symbol needed for the card's rank
     * used to construct the file name.
     */
    private String rankSymbol()
    {
        switch (rank)
        {
            case TWO:
                return "2";
            case THREE:
                return "3";
            case FOUR:
                return "4";
            case FIVE:
                return "5";
            case SIX:
                return "6";
            case SEVEN:
                return "7";
            case EIGHT:
                return "8";
            case NINE:
                return "9";
            case TEN:
                return "t";
            case JACK:
                return "j";
            case QUEEN:
                return "q";
            case KING:
                return "k";
            default:
                return "a";
        }
    }

    /**
     * Returns the suit symbol.
     * @return the symbol needed for the
     * card to construct the card's file name.
     */
    private String suitSymbol()
    {
        int pos = suit.ordinal();
        return "csdh".substring(pos, pos + 1);
    }

    /**
     * Flips the card over.
     */
    public void flip()
    {
        if (isFaceDown) setImage(getFileName());
        else setImage("cards/b.gif");

        isFaceDown = !isFaceDown;
    }
    
    /**
     * Returns the text representation of the card.
     *  @return text representation of the card.
     */
    public String ToString()
    {
        return rank.toString().charAt(0) +
               rank.toString().substring(1).toLowerCase() +
               " of " +
               suit.toString().charAt(0) +
               suit.toString().substring(1).toLowerCase();
    }
}
