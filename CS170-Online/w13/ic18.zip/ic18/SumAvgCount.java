/**
 *  SumAvgCount.java
 *  CS 170 Exercise 2008
 *  Illustrates initializing, summing, and counting a 1-D array
 *  Copyright (c) 2006 Stephen Dean Gilbert
 *
*/
import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.text.*;

public class SumAvgCount extends Applet implements ActionListener
{
    public void actionPerformed(ActionEvent ae)
    {
        // Here's our array
        double[] ar = new double[100];

        // 1. Get the length of the array

        // 2. Initialize with Math.random()

        // 3. Calculate sum and average using the
        //    "enhanced" for-each style for loop

        // 5. Count numbers larger & smaller than average
        //    Use the enhanced for loop

        // 6. Display results
        /* Uncomment once you have the variables defined
        output.setText("Sum = " + dfmt.format(sum) + ", Avg = "
                + dfmt.format(avg) + ", Larger = "
                + pfmt.format((double) larger / len) + ", Smaller = "
                + pfmt.format((double) smaller / len));
        */
    }

    /**
     * Variables used for user interface
     */
    private Button calcIt = new Button("Process an Array");
    private Label output = new Label("", Label.CENTER);

    // Format decimal & percentages
    private NumberFormat pfmt = NumberFormat.getPercentInstance();
    private NumberFormat dfmt = NumberFormat.getNumberInstance();

    /**
     * Initialize the user interface
     */
    public void init()
    {
        setLayout(new BorderLayout());
        add(output, "North");
        add(calcIt, "South");
        calcIt.addActionListener(this);
    }
}
