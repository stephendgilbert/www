import acm.program.*;
import acm.graphics.*;

import java.util.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

/**
 * Manipulating images as 2D arrays
 * 
 * @author Stephen Gilbert
 * @version Fall 2008
 */

public class ImageManip extends GraphicsProgram
{
    // An image that we can manipulate
    private GImage img = new GImage("madrid.jpg");

    /**
     * Handle the button clicks
     */
    public void actionPerformed(ActionEvent e)
    {
        Object clicked = e.getSource();
        // 1. Retrieve the pixels from the image
        int[][] pixels = img.getPixelArray();
        
        // Handle each of the buttons
        if (clicked == darkenBtn)
        {
            // 1. Darken each of the pixels in the array
            //  - Create a pair of nested loops that visit each element in pixels
            //  - Inside the inner loop, construct a Color object using element
            //  - Make the Color object "darker" by using the darker() method
            //      -- Remember, you'll have to store the result back in the Color object
            //  - Call the Color object's getRGB() method and store the result back in
            //      the current array element

            statusLbl.setText("Image darkened.");
        }
        else if (clicked == grayBtn)
        {
            // 2. Process the array of pixels (two methods; try both)
            //  -- Follow the instructions in "darken" to loop through the picture 
            //  -- After creating a Color object, extract the individual color values
            //      using getRed(), getBlue(), and getGreen(). Store these in variables
            //  -- For the first run, average the pixel values by adding the red,
            //      green and blue together and dividing by 3. Use this number and
            //      the 3-parameter Color constructor to construct a gray Color
            //      -- Extract the gray value's getRGB() and store it back in the array
            //  -- For the second run, do the same thing but multiply the individual
            //      values by the luminance % like this: red (.299), green(.587), 
            //      blue(.114). Add the three numbers together to construct your 
            //      gray Color object, before storing it back in the array.
            
            statusLbl.setText("Grayscale Image.");
        }
        else if (clicked == mirrorBtn)
        {
            // Process the array of pixels to create a mirror image.
            //  -- For the column loop bounds (len), use pixels[0].length / 2
            //  -- Copy pixels[r][c] to pixels[r][len - 1 - c]
            // This copies the left half to the right half for the mirror image.
            statusLbl.setText("Mirror Image.");
        }
        else if (clicked == rotateBtn)
        {
            // Rotate the entire matrix to the right
            statusLbl.setText("Rotated Image.");
        }
        else if (clicked == shrinkBtn)
        {
            // Create a new array 1/2 the size of the original
            // Copy every other pixel into the new array
            statusLbl.setText("Shrunk Image.");
        }
        else if (clicked == resetBtn)
        {
            img = new GImage("madrid.jpg");
            pixels = img.getPixelArray();
            statusLbl.setText("Original Image.");
        }
        
        // Remove the old image and create a new one
        remove(img);
        img = new GImage(pixels);
        // Add the image, adjust the size
        add(img, 0,0);
        adjustSize();
    }

    
    public void adjustSize()
    {
        setSize((int)(img.getWidth() + 5), (int)(img.getHeight() + 110));
    }
        
    /**
     * The standard Java entry point. DON'T MODIFY THIS METHOD.
     */
    public static void main(String[] args)
    {
        new ImageManip().start(args);
    }

    
    /**
     * Initialize the user interface
     */
    public void init()
    {
        // Set the background to black
        setBackground(new Color(0, 0, 0));
        
        // Initialize the GUI
        darkenBtn = new JButton("Darken");
        grayBtn = new JButton("Gray");
        mirrorBtn = new JButton("Mirror");
        rotateBtn = new JButton("Rotate");
        shrinkBtn = new JButton("Shrink");
        resetBtn = new JButton("Reset");
        
        statusLbl = new JLabel("Welcome to Image Manipulation");
        
        add(darkenBtn, SOUTH);
        add(grayBtn, SOUTH);
        add(mirrorBtn, SOUTH);
        add(rotateBtn, SOUTH);
        add(shrinkBtn, SOUTH);
        add(resetBtn, SOUTH);
        add(statusLbl, NORTH);

        addActionListeners();

        add(img,0, 0);
        adjustSize();
    }

    /**
     * User interface controls
     */
    private JButton darkenBtn;          // Darken the image
    private JButton grayBtn;            // Gray-scale image
    private JButton mirrorBtn;          // Mirror the image
    private JButton rotateBtn;          // Rotate the image right
    private JButton shrinkBtn;          // Shrink the image
    private JButton resetBtn;           // Original image
    private JLabel statusLbl;           // Display the status
}
