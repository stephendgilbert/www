/**
 *  InputResizableArrayClass.java
 *  CS 170 Exercise
 *  Retrieving input using the ResizableArrayClass class.
 *
 *  @author Stephen Gilbert
 *  @version 2.0, April 2008
*/
import java.util.*;

public class InputResizableArrayClass
{
    public static void main(String[] args)
    {
        // Scanner for input
        Scanner scan = new Scanner(System.in);

        // 1. Create a ResizableArrayClass variable named ar

        // Get the input from the user
        System.out.println("Enter positive real numbers.");
        System.out.println("Enter 0 or a negative number to quit.");
        double num;
        while ((num = scan.nextDouble()) > 0)
            ; // 2. Add the number to the array

        // 3. Display results
        System.out.print("ar = ");
    }
}
