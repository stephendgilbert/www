/**
 *  ResizableArrayClass.java
 *  CS 170 Exercise
 *  An array class that expands as you add elements.
 *
 *  @author Stephen Gilbert
 *  @version 2.0, April 2008
*/
public class ResizableArrayClass
{
    // instance variables
    private int size = 0;
    private int capacity = 1;
    private double[] ar = new double[capacity];

    /**
     * @return true if the array is full
     */
    public boolean isFull()
    {
        return size >= capacity;
    }

    /**
     * @param value the new value to be added to the array
     * If the array is full, then a new element is added
     */
    public void add(double value)
    {
        if (isFull()) expand();
        ar[size] = value;
        size++;
    }

    /**
     * Increases the length of the array by 1
     */
    public void expand()
    {
        capacity++;
        double[] temp = new double[capacity];
        System.arraycopy(ar, 0, temp, 0, size);
        ar = temp;
    }

    /**
     * Prints the valid elements in this array
     */
    public String toString()
    {
        String ret = "{";
        if (size == 0)
        {
            ret += "}";
        }
        else
        {
            for (int i = 0; i < size -1; i++)
                ret += ar[i] + ", ";
            ret += ar[size-1] + "}";
        }
        return ret;
    }
}
