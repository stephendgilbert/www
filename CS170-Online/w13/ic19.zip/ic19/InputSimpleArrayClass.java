/**
 *  InputSimpleArrayClass.java
 *  
 *  Adding items to a "partially filled" array
 *  that has been encapsulated into a class
 *  
 *  @author Stephen Gilbert
 *  @version 3.0, Java 7 version, Spring 2008
 */
import java.util.*;

public class InputSimpleArrayClass
{
    public static void main(String[] args)
    {
        // Scanner for input
        Scanner scan = new Scanner(System.in);

        // 1. Create a SimpleArrayClass object named ar
        

        // Get the input from the user
        System.out.println("Enter up to 100 positive real numbers.");
        System.out.println("Enter 0 or a negative number to quit.");
        
        // 2. Loop while there is still more room in the array 
        while (true)
        {
            // Read a number
            double num = scan.nextDouble();

            // If the user wants to exit, then leave
            if (num <= 0)
                break;

            // 3. Otherwise store the number at size
            
        }

        // 4. Display results
        System.out.print("ar = ");
    }
}

