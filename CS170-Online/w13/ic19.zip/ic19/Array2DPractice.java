import java.util.Scanner;

/**
 * Array2D practice exercises for CS 170
 * @author Stephen Gilbert
 * @version 2008
 */
public class Array2DPractice
{
    /**
     * average: averages a 2D array of int.
     * @param a the 2D int array to average.
     */
    
    /**
     * average: averages a 1D array of int.
     * @param a the 1D int array to average.
     */

    /**
     * average: averages a elements of once column of a 2D array of int.
     * @param a the 2D int array to average.
     * @param col the column to average
     */
    
    /**
     * rotateRight: create a new array that rotates the elements to the right.
     * The first row in the new array is the first column in the old.
     * 
     * @param a the 2D int array to rotate.
     * @return a new, rotated 3D array.
     */
    
    /**
     * Process a 2D array and the rows in a 2D array.
     */
    public void run()
    {
        // Write the average() method
        int[][] values = { {2, 5}, {6, 7}, {3, 9} };
        
        /* 1. Uncomment this.
        System.out.println("The average in values is " + 
                average(values));
        */
        
        /* 2. Add code to average a single row of values */
        
        /* 3. Add code to average a single column of values */
        
        /* 4. Rotate values right, store in rotated, and print it out */
        
    }
    /**
     * Process a 2D array and the rows in a 2D array
     */
    public static void main(String[] args)
    {
        new Array2DPractice().run();
    }
    
}
