import java.util.Scanner;
/**
 * This program counts the syllables of all words in a sentence.
 * 
 * @author (Who are you?)
 * @version (What's the date?)
 */
public class SyllableCounter
{
    /**
     * The starting point for the program.
     * @param args command-line arguments.
     */
    public static void main( String[] args )
    {
        Scanner in = new Scanner( System.in );

        System.out.println( "Enter a sentence ending in a period." );

        String input;
        do
        {
            input = in.next();
            Word w = new Word( input );
            int syllables = w.countSyllables();
            System.out.println( "Syllables in " + input + ": " + syllables );
        }
        while ( !input.endsWith( "." ) );
    }
}
