import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests the DataSet class for CS 170 Homework 26
 * @author Stephen Gilbert
 * @version Fall 2008
 */
public class HW26Test
{
    private DataSet ds;
    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception
    {
        ds = new DataSet();
    }


    /**
     * Test count for Empty DataSet.
     */
    @Test
    public void testCountForEmptyDataSet()
    {
        assertEquals( 
            "Empty data set: count should be 0",
            0, 
            ds.getCount() );
    }

    /**
     * Test standard deviation for Empty DataSet.
     */
    @Test
    public void testStandardDeviationForEmptyDataSet()
    {
        assertEquals( 
            "Empty data set: standard deviation should be NaN",
            Double.NaN, 
            ds.getStandardDeviation());
    }

    /**
     * Test average for Empty DataSet.
     */
    @Test
    public void testAverageForEmptyDataSet()
    {
        assertEquals( 
            "Empty data set: average should be NaN",
            Double.NaN, 
            ds.getAverage());
    }

    /**
     * Test count for single-item DataSet.
     */
    @Test
    public void testCountForSingleItemDataSet()
    {
        ds.add( 5.0 );
        assertEquals( 
            "Single item data set: count should be 1",
            1, 
            ds.getCount() );
    }

    /**
     * Test standard deviation for single-item DataSet.
     */
    @Test
    public void testStandardDeviationForSingleItemDataSet()
    {
        ds.add( 5.0 );
        assertEquals( 
            "Single-item data set: standard deviation should be NaN",
            Double.NaN, 
            ds.getStandardDeviation());
    }

    /**
     * Test average for single-item DataSet.
     */
    @Test
    public void testAverageForSingleItemDataSet()
    {
        ds.add( 5.0 );
        assertEquals( 
            "Single-item data set: average should be 5.0",
            5.0, 
            ds.getAverage(),
            0.00001);
    }
    
    /**
     * Test count for two-item DataSet.
     */
    @Test
    public void testCountForTwoItemDataSet()
    {
        ds.add( 5.0 );
        ds.add( 2.5 );
        assertEquals( 
            "Two-item data set: count should be 2",
            2, 
            ds.getCount() );
    }

    /**
     * Test standard deviation for two-item DataSet.
     */
    @Test
    public void testStandardDeviationForTwoItemDataSet()
    {
        ds.add( 5.0 );
        ds.add( 2.5 );
        assertEquals( 
            "Two-item data set: standard deviation should be 1.76777",
            1.76777, 
            ds.getStandardDeviation(),
            0.00001);
    }

    /**
     * Test average for two-item DataSet.
     */
    @Test
    public void testAverageForTwoItemDataSet()
    {
        ds.add( 5.0 );
        ds.add( 2.5 );
        assertEquals( 
            "Two-item data set: average should be 3.75",
            3.75, 
            ds.getAverage(),
            0.00001);
    }

    /**
     * Test count for four-item DataSet.
     */
    @Test
    public void testCountForFourItemDataSet()
    {
        ds.add( 5.0 );
        ds.add( 6.0 );
        ds.add( 8.0 );
        ds.add( 9.0 );
        assertEquals( 
            "Four-item data set: count should be 4",
            4, 
            ds.getCount() );
    }

    /**
     * Test standard deviation for four-item DataSet.
     */
    @Test
    public void testStandardDeviationForFourItemDataSet()
    {
        ds.add( 5.0 );
        ds.add( 6.0 );
        ds.add( 8.0 );
        ds.add( 9.0 );
        assertEquals( 
            "Four-item data set: standard deviation should be 1.83",
            1.82574, 
            ds.getStandardDeviation(),
            0.00001);
    }

    /**
     * Test average for four-item DataSet.
     */
    @Test
    public void testAverageForFourItemDataSet()
    {
        ds.add( 5.0 );
        ds.add( 6.0 );
        ds.add( 8.0 );
        ds.add( 9.0 );
        assertEquals( 
            "Four-item data set: average should be 7",
            7.0, 
            ds.getAverage(),
            0.00001);
    }

}
