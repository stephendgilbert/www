/**
 * This class is used to calculate the average and standard deviation of a data
 * set.
 * 
 * CS 170 Homework 26 Fall 2008
 * 
 * @author (Your name here)
 * @version (Today's date)
 */
/**
   This class is used to calculate the average and standard deviation
   of a data set.
*/
public class DataSet
{
    /**
       Constructs a DataSet object to hold the total number of inputs,
       the sum, and the sum of square.
    */
    public DataSet()
    {

    }

    /**
       Adds a value to this data set.
       @param x the input value
    */
    public void add(double x)
    {
        
    }

    /**
       Method used to calculate the average of the data set.
       @return average the average of the data set
    */
    public double getAverage()
    {
        return 0.0; // replace this
    }

    /**
       Method used to calculate the standard deviation.
       @return stddev the standard deviation of data set
    */
    public double getStandardDeviation()
    {
        return 0.0; // replace this
    }

    /**
       Gets the total number of input values.
       @return n the total number of inputs
    */
    public int getCount()
    {
        return 0; // replace this
    }

    private double sum;
    private double sumSquare;
    private int n;
}
