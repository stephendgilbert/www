import java.util.Scanner;

/**
 * 	CurrencyConverter.java: Uses a loop to convert dollars to Euros.
 *
 *	@author Stephen Dean Gilbert
 *	@version Fall 2008 
 */

public class CurrencyConverter
{

    /**
     *	Convert dollars to Euros.
     */
    public static void main(String[] args)
    {
        // Prompt: "Dollar value (Q to quit):"
        // Get the user input and store in a string
        // While the user did not enter a "Q"
            // Convert input to a double
            // Calculate the converted value
            // Print: "100.00 dollar = 79.45 Euro"
            // Prompt: "Dollar value (Q to quit):"
            // Get the user input and store in a string
        // End of loop
    }
}
