import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/**
 *  Illustrates the use of a break statement in a loop
 *  CS 170 Exercise
 *  @author Add your name here
 *  @version Add today's date
 */

public class BreakFor extends Applet
{
    private TextField myTF = new TextField();

    public void init()
    {
        setLayout(new BorderLayout());
        add(myTF, BorderLayout.NORTH);
        myTF.addActionListener(new NumberParser());
    }

    /**
     *  Uses break to non-digits from a "text-form" integer
     */
    private class NumberParser implements ActionListener
    {
        public void actionPerformed(ActionEvent ae)
        {
            String str = myTF.getText();
            String ans = "";

            // 1. Write a for loop that goes through str
            // 2. Extract the current character
            // 3. If the character is not a period, then 
            //    add it to the end of the answer.
            // 4. If it is a period, terminate the loop
            
            myTF.setText(ans);
        }
    }
}
