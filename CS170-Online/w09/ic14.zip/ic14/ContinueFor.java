import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/**
 *  Illustrates the use of a continue statement in a loop
 *  CS 170 Exercise
 *  @author Add your name here
 *  @version Add today's date
 */

public class ContinueFor extends Applet implements ActionListener
{
    private Label output = new Label();
    private TextField numTF  = new TextField();

    public void init()
    {
        setLayout(new BorderLayout());
        add(numTF, BorderLayout.SOUTH);
        add(output,BorderLayout.NORTH);
        numTF.addActionListener(this);
    }

    public void actionPerformed(ActionEvent ae)
    {
        // Convert a string to an integer
        // 1. Extract the string from the text-field
        String str = numTF.getText();
        int result = messyStringToInt(str);
        output.setText("The converted number is " + result);
    }

    int messyStringToInt(String str)
    {
        int result = 0;
        
        // 1. use the String's length as the loop bounds
        // 2. Extract each character from the String
        // 3. Use the Character.isDigit() to see if it's a number
        // 4. If it's not, we can restart the loop using continue
        // 5. If it's a digit, convert to a binary number
        //      // What does that mean?????
        // 6. Add it to a running total
        //      // What do you need to do when you get another digit?
        //      // Think about 10's place, 100's place, etc.
        // 7. Return the converted number

        return result;
    }
}
