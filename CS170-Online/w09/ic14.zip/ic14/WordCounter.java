/**
 *  Counts the number of words in the TextArea wordsTA
 *  Illustrates using the Scanner class and Iterators
 *  CS 170 example
 *
 *  @author (Put your name here)
 *  @version (Put today's date here)
 */

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.util.*;

public class WordCounter extends Applet
{
    private TextArea wordsTA = new TextArea();
    private Label wordCount = new Label("Words: 0000000");
    private Button count = new Button(" Count Words ");

    public void init()
    {
        setLayout(new BorderLayout());
        // Panel for the button and label
        Panel p = new Panel();
        p.add(count);
        p.add(wordCount);
        add(p, BorderLayout.NORTH);

        add(wordsTA, BorderLayout.CENTER);

        count.addActionListener(new Counter());
    }

    /**
     * Counts the words in the TextArea
     */
    private class Counter implements ActionListener
    {
        public void actionPerformed( ActionEvent ae)
        {
            wordCount.setText("Words = " + countWords());
        }

        public int countWords()
        {
            // Retrieve the string from the text area
            String text = wordsTA.getText();

            int numWords = 0;

            // Loop through the text and retrieve each character

            return numWords;
        }
    }
}
