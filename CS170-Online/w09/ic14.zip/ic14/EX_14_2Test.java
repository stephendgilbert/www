import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for the doubleChar method.
 * @author Stephen Gilbert
 * @version Fall 2008
 */
public class EX_14_2Test
{
    private EX_14_2 obj;

    /**
     * Creates the object to test.
     * @throws Exception
     */
    @Before
    public void setUp() throws Exception
    {
        obj = new EX_14_2();
    }


    /**
     * Test "The".
     */
    @Test
    public void testDoubleCharThe()
    {
        assertEquals("TThhee", obj.doubleChar( "The" ));
    }

    /**
     * Test "AAbb".
     */
    @Test
    public void testDoubleCharAAbb()
    {
        assertEquals("AAAAbbbb", obj.doubleChar( "AAbb" ));
    }

    /**
     * Test "Hi-There".
     */
    @Test
    public void testDoubleCharHiThere()
    {
        assertEquals("HHii--TThheerree", obj.doubleChar( "Hi-There" ));
    }

    /**
     * Test "Word!".
     */
    @Test
    public void testDoubleCharWord()
    {
        assertEquals("WWoorrdd!!", obj.doubleChar( "Word!" ));
    }

    /**
     * Test "!!".
     */
    @Test
    public void testDoubleCharDoubleBang()
    {
        assertEquals("!!!!", obj.doubleChar( "!!" ));
    }

    /**
     * Test "".
     */
    @Test
    public void testDoubleCharEmptyString()
    {
        assertEquals("", obj.doubleChar( "" ));
    }

    /**
     * Test "a".
     */
    @Test
    public void testDoubleCharA()
    {
        assertEquals("aa", obj.doubleChar( "a" ));
    }

    /**
     * Test " ".
     */
    @Test
    public void testDoubleCharSpace()
    {
        assertEquals("  ", obj.doubleChar( " " ));
    }

    /**
     * Test "aa".
     */
    @Test
    public void testDoubleCharAA()
    {
        assertEquals("aaaa", obj.doubleChar( "aa" ));
    }
}
