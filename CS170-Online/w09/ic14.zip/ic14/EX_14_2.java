/**
 * EX_14_2: A Counted While Loop
 * @author <your name here>
 * @version Fall 2008
 */
public class EX_14_2
{
    /**
     * Write a method named doubleChar that takes a single
     * string parameter. The method should return a string where 
     * for every character in the original string, there are two 
     * characters in the returned string. Use the while loop,
     * not the for loop, to complete this version.
     * 
     * Examples:
     * doubleChar("The") should return "TThhee"
     * doubleChar("AAbb") should return "AAAAbbbb"
     * doubleChar("Hi-There") should return "HHii--TThheerree"
     * 
     * @param str the string to double.
     * @return the doubled string.
     */
}
