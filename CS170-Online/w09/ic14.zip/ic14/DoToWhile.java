/**
 *  DoToWhile.java
 *  Convert a do-while loop to a while loop
 *
 *  @author (Your name)
 *  @version (Today's date)
 */
public class DoToWhile
{
    public static void main(String[] args)
    {
        int n = 1;
        double x = 0;
        double s;
        do
        {
             s = 1.0 / (n * n);
             x = x + s;
             n++;
        }
        while (s > 0.01);

        System.out.printf("n = %d, x = %.3f, s = %.3f%n", n, x, s);

    }
}
