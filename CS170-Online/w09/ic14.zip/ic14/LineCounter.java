import java.io.*;
import java.util.Scanner;

/**
 * LineCounter.java: Reads the number of lines in a File.
 * 
 *    @author (Put your name here)
 *    @version (Put today's date here)
 */

public class LineCounter
{
    /**
     *  Reads the number of lines in a file.
     */
    public static void main(String[] args) throws Exception
    {
        // Create a Scanner using the file "moby.txt"

        int numLines = 0;
        
        // Use the Scanner as an iterator to count the number of lines.

        System.out.printf("%,d lines in Moby Dick.", numLines);
    }
}
