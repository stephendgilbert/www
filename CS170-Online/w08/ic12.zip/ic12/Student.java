/**
 *  Computes a letter grade using multi-way selection
 *  A CS 170 example
 *
 *  @author (Add your name here)
 *  @version (Add the date here)
 */

class Student
{
    // instance variables
    private String name = "";
    private double totalPoints = 0.0;
    private double studentPoints = 0.0;

    // Constructor
    public Student(String nm)
    {
        name = nm;
    }

    /**
     *  A mutator method that adds an assignment or test score
     *
     * @param points points earned on this assigment
     * @param possiblePoints possible points on this assignment
     */
    public void addScore(double points, double possiblePoints)
    {
        studentPoints += points;
        totalPoints += possiblePoints;
    }

    /**
     *  Calculate the current percentage score
     *  @return current percentage or NaN if no scores recorded
     */
    public double getPercentage()
    {
        return 100.0 * studentPoints / totalPoints;
    }

    /**
     *  Calculate the current letter grade
     *  @return current letter grade using multi-way selection
     */
    public String getLetterGrade()
    {
        return "";
    }
}