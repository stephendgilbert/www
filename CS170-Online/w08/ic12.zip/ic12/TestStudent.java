/**
 *  Computes a letter grade using multi-way selection
 *  A CS 170 example
 *
 *  @author Steve Gilbert
 *  @version 3.0, Spring 2008
 */

public class TestStudent
{
    public static void main(String[] args)
    {
        // 1. Add a Student and add some assignments
        Student fred = new Student("Fred");
        fred.addScore(75, 100);
        fred.addScore(80, 100);
        fred.addScore(15, 15);

        // 2. Print Fred's percentage
        double percent = fred.getPercentage();
        System.out.printf(
            "Fred's current percentage is : %.1f%%%n", percent);

        // 3. Print Fred's letter grade
        System.out.printf(
            "Fred's letter grade is : %s%n", fred.getLetterGrade());
    }
}
