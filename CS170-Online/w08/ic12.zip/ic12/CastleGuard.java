import cs170.*;
// -------------------------------------------------------------------------
/**
 *  A Robot that can patrol a castle.
 * 
 *  @author  Stephen Gilbert
 *  @version February 2008
 */
public class CastleGuard extends OCRobot
{
    //~ Constructor ...........................................................
    //~ Methods ...............................................................
    /**
     * Allows the robot to turn right;
     */
    public void turnRight()
    {
        turnLeft();
        turnLeft();
        turnLeft();
    }
    
    /**
     * Go to the starting position at the castle.
     * Assumes karel starts at 1,1 facing north.
     * Destination is 4st, 3av, facing North.
     */
    public void goToWork()
    {
        move();
        move();
        move();
        turnRight();
        move();
        move();
        turnLeft();
    }
    
    /**
     * Patrol a section of the castle wall.
     */
    public void patrolWall()
    {
        move();
        move();
    }
    
    /**
     * Patrols a turret.
     */
    public void patrolTurret()
    {
        turnLeft();
        move();
        turnRight();
        move();
        move();
        turnRight();
        move();
        move();
        turnRight();
        move();
        turnLeft();
    }
    
    /**
     * Patrols the castle one time.
     */
    public void patrolCastle()
    {
        patrolWall();
        patrolTurret();
        patrolWall();
        patrolTurret();
        patrolWall();
        patrolTurret();
        patrolWall();
        patrolTurret();
    }
}
