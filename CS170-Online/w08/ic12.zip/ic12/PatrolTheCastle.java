import cs170.*;

/**
 *  This is a class demonstration showing how simple it is to 
 *  use methods to solve a complex problem.
 *
 *  @author  Stephen Gilbert
 *  @version Spring 2008
 */
public class PatrolTheCastle implements RobotTask
{
    //~ Instance/static variables .............................................
    private CastleGuard karel = null; // don't modify this

    //~ Methods ...............................................................

    /**
     * This task creates a castle guard and orders him to walk
     * around the castle on patrol.
     */
    public void task()
    {
        World.startFromURL(
            "http://csjava.occ.cccd.edu/~gilberts/worlds/castle.kwld");
        World.setDelay(20);
        
        karel = new CastleGuard();
        
        karel.goToWork();
        karel.patrolCastle();
        karel.turnOff();
    }


    /**
     * Returns a copy of the karel instance variable for testing.
     * DON'T CHANGE THIS METHOD
     * @return reference to OCRobot instance variable.
     */
    public OCRobot robot()
    {
        return karel;
    }
}
