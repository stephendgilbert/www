import cs170.*;

/**
 *  Walk a maze with beepers in an unknown location.
 *  Create a Robot class called MazeWalker that walks the maze
 *  picking up the two beepers that it contains.
 *
 *  @author  your-pid (and partner's, if in lab)
 *  @version (place the date here)
 */
public class WalkMaze implements RobotTask
{
    //~ Instance/static variables .............................................
    private MazeWalker karel = null;

    //~ Methods ...............................................................

    /**
     * Initializes Karel's world, creates a robot in the world, and
     * sends it commands.
     * Walks a maze and picks up two randomly-placed beepers.
     */
    public void task()
    {
        World.startFromURL("lab02a.kwld");
        
        karel = new MazeWalker();   // Or, add a constructor!
    }


    /**
     * Returns a copy of the karel instance variable for testing.
     * DON'T CHANGE THIS METHOD
     * @return reference to OCRobot instance variable.
     */
    public OCRobot robot()
    {
        return karel;
    }
}
