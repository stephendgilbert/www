/**
 *  CS 170 Final Exam Problem 4: Processing Arrays.
 *
 *  For Problem 4 remember define a method that processes
 *  an array of objects. The sum() method should accept an array of
 *  Coin objects and return the sum of their values as a double. 
 *  
 *  Make sure that the Problem 4 run method works correctly.
 *  For the actual exam, you should be able to write methods that
 *  average (using different kinds of averaging algorithms including
 *  weighted averages and centered averages) and that make use of
 *  the algorithms for finding extreme values. 
 */
public class Problem4
{
    /**
     * DEFINE THE sum() METHOD HERE.
     * @param coins an array of Coin objects
     * @return the value of all the coins as a double, representing a
     * dollar amount. 
     */

    
    
    /**
     * Creates some Coin objects and prints their values.
     */
    public void run()
    {
    /**
     * Un-comment this code after you have defined the sum() method
         
        Coin[] purse = {
            new Coin(25), new Coin(5), new Coin(5),
            new Coin(10), new Coin(1), new Coin(5),
            new Coin(1), new Coin(25)
        };
        
        System.out.println("The variable purse contains ");
        for (Coin c: purse)
            System.out.printf("One %s%n", c.toString());
        String fmt = "The value of these coins is $%.2f%n";
        System.out.printf(fmt, sum(purse));
    */
    }
    
    /**
     *  Calls the run() method.
     */
    public static void main(String[] args)
    {
        new Problem4().run();
    }
}
