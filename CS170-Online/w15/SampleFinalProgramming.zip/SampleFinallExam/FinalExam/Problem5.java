import java.util.*;
/**
 *  CS 170 Final Exam Problem 5: Interfaces.
 *
 *  For Problem 5 remember how to implement the Comparable<T> interface.
 *  The run() method in Problem5 creates an array of Coin objects and
 *  then shuffles them before printing the values. Then, the Coins are
 *  sorted, and the contents of the bank are printed out.
 *  
 *  Implement the Comparable<Coin> interface in the Coin.java file
 *  so that Problem5 works correctly. 
 */
public class Problem5
{
    /**
     * Creates some random Coin objects and print their values.
     */
    public void run()
    {
    /**
     * Un-comment the code below once you have implemented the
     * Comparable<Card> interface in the Card class.
         
        int values[] = {1, 5, 10, 25};
        Random gen = new Random();
        ArrayList<Coin> bank = new ArrayList<Coin>();
        int MAX_COINS = 15;
        
        for (int i = 0; i < MAX_COINS; i++)
            bank.add(new Coin(values[gen.nextInt(values.length)]));
        
        System.out.print("Before shuffling, bank contains: {");
        for (int i = 0; i < bank.size() - 1; i++)
            System.out.print(bank.get(i).getValue() + ", ");
        System.out.println(bank.get(bank.size()-1).getValue() + "}");
        
        Collections.shuffle(bank);
        System.out.print("After shuffling, bank contains: {");
        for (int i = 0; i < bank.size() - 1; i++)
            System.out.print(bank.get(i).getValue() + ", ");
        System.out.println(bank.get(bank.size()-1).getValue() + "}");        
        
        Collections.sort(bank);
        System.out.print("After sorting, bank contains: {");
        for (int i = 0; i < bank.size() - 1; i++)
            System.out.print(bank.get(i).getValue() + ", ");
        System.out.println(bank.get(bank.size()-1).getValue() + "}");
    */
    }
    
    /**
     *  Calls the run() method.
     */
    public static void main(String[] args)
    {
        new Problem5().run();
    }
}
