/**
 *  CS 170 Final Exam Problem 2: Overloading Methods and Constructors.
 *
 *  For Problem 2 you'll define an overloaded method or constructor. 
 *  
 *  Add a second constructor to the Coin class that takes a double 
 *  parameter. Use the parameter you receive to initialize 
 *  the value field. You'll have to convert the parameter to an 
 *  appropriate integer. For instance, the actual parameter .25 should 
 *  be stored as 25 in the value instance variable. 
 *  
 *  Do not add any additional instance variables and do not do any
 *  error checking. 
 *  
 *  Make sure that the Problem 2 run method works correctly. 
 */
public class Problem2
{
    /**
     * Creates some Coin objects and prints their values.
     */
    public void run()
    {
        /* Un-comment this code once you have defined your overloaded
         * constructor.

        Coin penny = new Coin(.01);
        Coin nickel = new Coin(.05);
        Coin dime = new Coin(.10);
        Coin quarter = new Coin(.25);
        Coin whatDat = new Coin(.33);
        
        String fmt = "One %s has the value %d%n";
        System.out.printf(fmt, penny.toString(), penny.getValue());
        System.out.printf(fmt, nickel.toString(), nickel.getValue());
        System.out.printf(fmt, dime.toString(), dime.getValue());
        System.out.printf(fmt, quarter.toString(), quarter.getValue());
        System.out.printf(fmt, whatDat.toString(), whatDat.getValue());

         */
    }

    /**
     *  Calls the run() method.
     */
    public static void main(String[] args)
    {
        new Problem2().run();
    }
}
