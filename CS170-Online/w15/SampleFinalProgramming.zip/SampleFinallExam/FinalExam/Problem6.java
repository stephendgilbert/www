import java.util.*;
/**
 *  CS 170 Final Exam Problem 6: Array Programming (15 Points)
 *  For Problem 6 you should use loops and selection to solve the
 *  array problem listed below. Write your code where indicated.  
 */
public class Problem6
{
    /**
     * Define the tenRun() method here.
     * For each multiple of 10 in the given array, change all 
     * the values following it to be that multiple of 10, until 
     * encountering another multiple of 10. 
     * 
     * Here's an example: {2, 10, 3, 4, 20, 5} returns the new 
     * array {2, 10, 10, 10, 20, 20} because all of the values past
     * 10 are converted to 10s until 20 is encountered. Then, all of
     * the values until the end of the array are changed to 20s.
     * 
     * The run() method contains more examples.
     * Don't modify the original array.
     * 
     * @param nums an array of int (may be 0 length)
     * @return a new array modified as described
     */ 
    public int[] tenRun(int[] nums)
    {
        return new int[0];
    }

    /**
     * Creates some arrays and then call tenRun.
     * Check the expected against the actual values.
     */
    public void run()
    {
        int[] a = {2, 10, 3, 4, 20, 5};
        int[] aOrg = a.clone();
        int[] b = {2, 10, 10, 10, 20, 20};
        // Check to make sure that a converts to b
        checkEqual(tenRun(a), b);
        // Check to make sure a was not modified by tenRun 
        checkEqual(a, aOrg);

        int[] c = {10, 1, 20, 2};
        int[] d = {10, 10, 20, 20};
        // Check to make sure that c converts to d
        checkEqual(tenRun(c), d);

        int[] e = {10, 1, 9, 20};
        int[] f = {10, 10, 10, 20};
        // Check to make sure that e converts to f
        checkEqual(tenRun(e), f);
    }
    
    /**
     * Checks two arrays for equality.
     * @param a an array of int
     * @param b an array of int
     */
    private void checkEqual(int[] a, int[] b)
    {
        String aStr = Arrays.toString(a);
        String bStr = Arrays.toString(b);
        
        if (aStr.equals(bStr))
            System.out.println("EQUAL: both contain " + aStr);
        else
            System.out.println("ERROR: a = " + aStr + ", b = " + bStr);
    }

    /**
     *  Calls the run() method.
     */
    public static void main(String[] args)
    {
        new Problem6().run();
    }
}
