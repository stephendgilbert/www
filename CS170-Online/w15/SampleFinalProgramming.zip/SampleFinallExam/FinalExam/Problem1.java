/**
 *  CS 170 Final Exam Problem 1: Defining Classes.
 *
 *  For Problem 1 you'll have to remember how to define a class,
 *  how to write methods,  pass arguments, and write constructors
 *  and accessors. For this problem, write the definition for 
 *  the Coin class. You will modify this definition in subsequent 
 *  problems.
 *  
 *  The Coin class represents a single U.S. coin. Each Coin object 
 *  has an int value, which should be 1, 5, 10, or 25, as its only instance 
 *  variable. Supply the Coin class with a constructor that takes an
 *  int parameter and sets the value field. Don't do any error checking
 *  in the constructor.
 *  Add two accessor methods: 
 *   - getValue() which returns the Coin's value, and 
 *   - toString(), which returns the name of the particular Coin object, 
 *   in this exact form : "Penny", "Nickel", "Dime", or "Quarter".
 *   
 *   Once you have defined the Coin class (in the separate file, Coin.java)
 *   then un-comment the code inside the run() method below and make sure 
 *   that the Problem 1 run method works correctly before
 *   going on to the other problems.
 */
public class Problem1
{
    /**
     * Creates some Coin objects and prints their values.
     */
    public void run()
    {
    /* Un-comment out the code below after you have written
     * the initial definition for the Coin class.
      
        Coin penny = new Coin(1);
        Coin nickel = new Coin(5);
        Coin dime = new Coin(10);
        Coin quarter = new Coin(25);
        Coin whatDat = new Coin(33);
        
        String fmt = "One %s has the value %d%n";
        System.out.printf(fmt, penny.toString(), penny.getValue());
        System.out.printf(fmt, nickel.toString(), nickel.getValue());
        System.out.printf(fmt, dime.toString(), dime.getValue());
        System.out.printf(fmt, quarter.toString(), quarter.getValue());
        System.out.printf(fmt, whatDat.toString(), whatDat.getValue());
     */

    }

    /**
     *  Calls the run() method.
     */
    public static void main(String[] args)
    {
        new Problem1().run();
    }
}
