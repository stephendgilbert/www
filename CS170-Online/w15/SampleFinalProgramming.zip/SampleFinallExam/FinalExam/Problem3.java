/**
 *  CS 170 Final Exam Problem 3: Mutators and Exceptions.
 *
 *  For Problem 3 you'll define a mutator method and throw an exception. 
 *  
 *  Add a setValue() method to the Coin class. 
 *  Your setValue() method should take a single int parameter and 
 *  should use exception handling so that only valid Coin values 
 *  (1, 5, 10, 25) can be used. You should throw an 
 *  IllegalArgumentException when someone attempts to set an invalid 
 *  Coin value. 
 *  
 *  Do not modify the Coin constructors/ Problem 1 and Problem 2 should 
 *  still work correctly, even though each of them constructs an invalid 
 *  Coin object. Make sure that the Problem 3 run method works correctly. 
 */
public class Problem3
{
    /**
     * Creates some Coin objects and prints their values.
     */
    public void run()
    {
/* Un-comment the code below after you have written
 * the setValue() mutator method.
         
        Coin one = new Coin(1);
        Coin two = new Coin(5);
        
        String fmt = "%s is a %s which has the value %d%n";
        System.out.printf(fmt, "one", one.toString(), one.getValue());
        System.out.printf(fmt, "two", two.toString(), two.getValue());
        System.out.println("--Calling setValue()");
        one.setValue(10);
        two.setValue(25);
        System.out.printf(fmt, "one", one.toString(), one.getValue());
        System.out.printf(fmt, "two", two.toString(), two.getValue());
        System.out.println("--Try an invalid value");
        try {
            one.setValue(33);
            System.out.printf(fmt, "WHOOPS! one is now a", one.toString(), 
                one.getValue());
        }
        catch (IllegalArgumentException e) {
            System.out.printf(fmt, "Good. One is still a", one.toString(), 
                one.getValue());
        }
*/
    }

    /**
     *  Calls the run() method.
     */
    public static void main(String[] args)
    {
        new Problem3().run();
    }
}
