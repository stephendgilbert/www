import java.util.*; // using Scanner
/**
 *  GetNums.java: Using try-catch.
 *  A CS 170 exercise.
 *
 *  @author Stephen Dean Gilbert
 *  @version May 12, 2008
 */

public class GetNums
{
    /**
     * Using the try-catch handlers.
     */
    public void run()
    {
        // Add your code here
        
    }

    /**
     *  Standard entry point.
     */
    public static void main(String[] args)
    {
        new GetNums().run();
    }
}
