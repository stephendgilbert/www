import java.applet.*;
import java.awt.*;
import java.awt.event.*;

/**
 * RuntimeExceptions.java: Illustrates several possible run-time errors.
 * 
 * @author Stephen Dean Gilbert
 * @version May 12, 2008
 */

public class RuntimeExceptions extends Applet
            implements ActionListener
{
    /**
     * Illustrates a NumberFormatException.
     */
    void convertCat()
    {
        String num = "Cat";
        int bad = Integer.parseInt(num);
    }

    /**
     * Illustrates an ArithmeticException.
     */
    void divideZero()
    {
        int numerator = 3;
        int denominator = 0;
        int problem = numerator / denominator;
    }

    /**
     * Illustrates a NullPointerException.
     */
    void tryNull()
    {
        b.setLabel("Uh Oh!");
    }

    /**
     * Create the user interface.
     */
    public void init()
    {
        add(one);
        add(two);
        add(three);
        one.addActionListener(this);
        two.addActionListener(this);
        three.addActionListener(this);
    }

    /**
     * Respond to each button click.
     */
    public void actionPerformed(ActionEvent theEvent)
    {
        if (theEvent.getSource() == one) convertCat();
        if (theEvent.getSource() == two) divideZero();
        if (theEvent.getSource() == three) tryNull();
    }

    /**
     * Button variables
     */
    private Button one = new Button("How much is a Cat?");
    private Button two = new Button("Problems with Math");
    private Button three = new Button("Nobody's Home");
    private Button b; // This has the value null
}
