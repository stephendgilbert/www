import acm.program.*;
import acm.graphics.*;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Deals a simple hand of BlackJack and displays it.
 * Dealer only plays after you've played.
 * 
 * @author (place your name here)
 * @version (place the date here)
 */

public class BeginnersBlackjack extends GraphicsProgram
{
    // Create Deck variable and a Deck object.
    Deck deck = new Deck();

    // EXERCISE: Create a Hand variable for the player and one for the dealer.
    // 
    
    /**
     * The playerPile just shows the player's cards as they are dealt.
     * The dealerPile shows the dealer's cards when dealt.
     */
    private GCompound playerPile = new GCompound();
    private GCompound dealerPile = new GCompound();
    
    /**
     * The newDeck() method.
     * Populate the deck of cards with 52 shuffled cards.
     */
    public void newDeck()
    {
        deck.removeAllCards();
        
        for (Suit suit : Suit.values())
        {
            for (Rank rank : Rank.values())
            {
                deck.addCard(new Card(rank, suit));
            }
        }
        deck.shuffle();
    }
    
    /**
     *  Show the cards in a Hand on the table
     *
     *  @param hand the Hand of cards
     *  @param pile the pile to display the cards
     */
    private void showCards(Hand hand, GCompound pile)
    {
        pile.removeAll();
        for (int i = 0; i < hand.getNumberOfCards(); i++)
        {
            Card c = hand.getCard(i);
            if (c.isFaceDown()) c.flip();
            pile.add(c, i * 20, 0);
        }
    }
    
    /**
     * EXERCISE
     * Display the score of a particular hand.
     * @param hand the Hand to score.
     */
    
    /**
     * EXERCISE
     * Create the NewHand class to respond to the newHandBtn class.
     * The class needs to implement the ActionListener interface.
     */

    
    /**
     * The standard Java entry point. DON'T MODIFY THIS METHOD.
     */
    public static void main(String[] args)
    {
        new BeginnersBlackjack().start(args);
    }

    /**
     * Initialize the user interface
     */
    public void init()
    {
        // Set the table color to a dark green
        setBackground(new Color(0, 128, 0));
        
        // Add the player and dealer piles to the table
        add(playerPile, 20, 20);
        add(dealerPile, getWidth()/2 + 20, 20);

        
        // EXERCISE: Initialize the three JLabels 
        logoLbl = new JLabel(new ImageIcon("cards/21.gif"));
        statusLbl = new JLabel("Welcome to Beginner's Blackjack");
        deckLbl = new JLabel();
        
        // EXERCISE: Add your labels to the program's surface. 
        add(logoLbl, SOUTH);
        add(statusLbl, NORTH);
        add(deckLbl, NORTH);
        
        // EXERCISE: Construct your JButtons and add them to the surface 
        newHandBtn = new JButton("New Hand");
        hitBtn = new JButton("Hit Me");
        standBtn = new JButton("Stand");
        
        add(newHandBtn, SOUTH);
        add(hitBtn, SOUTH);
        add(standBtn, SOUTH);
        
        // EXERCISE: Call method to have deckLbl display "0 Cards" 
        deckLbl.setText("       0 Cards");
        
        // EXERCISE: Test the BlackjackHand class 
        
        // EXERCISE: Hook up the newHandBtn JButton 
        
        // EXERCISE: Hook up the hitBtn JButton to an anonymous handler 
        
    }

    /**
     * User interface controls
     */

    // Create three JLabel instance variables 
    private JLabel statusLbl;
    private JLabel deckLbl;
    private JLabel logoLbl;

    // Create three JButton instance variables
    private JButton newHandBtn;
    private JButton hitBtn;
    private JButton standBtn;
    
    public static final int APPLICATION_WIDTH = 350;
    public static final int APPLICATION_HEIGHT = 250;
}
