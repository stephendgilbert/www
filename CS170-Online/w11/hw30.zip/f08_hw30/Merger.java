/**
 * Merger.java: CS 170, Fall 2008, Homework 30
 * 
 * @author (put your name here)
 * @version (put the date here)
 * 
 */
public class Merger
{
    /**
     * Write the method merge() here.
     * 
     * @param a an array of doubles
     * @param b an array of doubles
     * 
     * @return the merged array.
     * 
     * Example: 
     *   double[] a = {1.0, 2.0, 3.0};
     *   double[] b = {4.0, 5.0};
     *   merge(a, b) returns {1.0, 4.0, 2.0, 5.0, 3.0};
     */

}
