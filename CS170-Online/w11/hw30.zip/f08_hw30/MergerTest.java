import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
/**
 * Tests the merge method.
 * 
 * @author Stephen Gilbert
 * @version Fall 2008
 *
 */
public class MergerTest
{
    private Merger obj;
    private double[] a = {1.0, 2.0, 3.0};
    private double[] b = {4.0, 5.0};
    private double[] c = {6.0, 7.0};
    private double[] d = {};

    /**
     * Compares two arrays.
     */
    private boolean areEqual(double[] x, double[] y)
    {
        if (x.length == y.length)
        {
            for (int i = 0; i < x.length; i++)
                if (x[i] != y[i])
                    return false;
            return true;
        }
        return false;
    }
    
    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception
    {
        obj = new Merger();
    }

    /**
     * Test method for merge(double[], double[]).
     */
    @Test
    public void testMergeAB()
    {
        double[] ans = new double[]{1.0,4.0,2.0,5.0,3.0};
        assertTrue( areEqual(ans, obj.merge(a, b)));
    }

    /**
     * Test method for merge(double[], double[]).
     */
    @Test
    public void testMergeBA()
    {
        double[] ans = new double[]{4.0,1.0,5.0,2.0,3.0};
        assertTrue( areEqual(ans, obj.merge(b, a)));
    }
    
    /**
     * Test method for merge(double[], double[]).
     */
    @Test
    public void testMergeAC()
    {
        double[] ans = new double[]{1.0,6.0,2.0,7.0,3.0};
        assertTrue( areEqual(ans, obj.merge(a, c)));
    }

    /**
     * Test method for merge(double[], double[]).
     */
    @Test
    public void testMergeCA()
    {
        double[] ans = new double[]{6.0,1.0,7.0,2.0,3.0};
        assertTrue( areEqual(ans, obj.merge(c, a)));
    }

    /**
     * Test method for merge(double[], double[]).
     */
    @Test
    public void testMergeBC()
    {
        double[] ans = new double[]{4.0,6.0,5.0,7.0};
        assertTrue( areEqual(ans, obj.merge(b, c)));
    }

    /**
     * Test method for merge(double[], double[]).
     */
    @Test
    public void testMergeCB()
    {
        double[] ans = new double[]{6.0,4.0,7.0,5.0};
        assertTrue( areEqual(ans, obj.merge(c, b)));
    }

    /**
     * Test method for merge(double[], double[]).
     */
    @Test
    public void testMergeAD()
    {
        double[] ans = new double[]{1.0,2.0,3.0};
        assertTrue( areEqual(ans, obj.merge(a, d)));
    }

    /**
     * Test method for merge(double[], double[]).
     */
    @Test
    public void testMergeDA()
    {
        double[] ans = new double[]{1.0,2.0,3.0};
        assertTrue( areEqual(ans, obj.merge(d, a)));
    }
}
