import static net.sf.webcat.ReflectionSupport.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 *  TestCommonEnd.java: Tests the commonEnd method.
 *
 *  @author Stephen Dean Gilbert
 *  @version Apr 13, 2008
 */

public class TestCommonEnd
{

    private ArrayTest obj;
    
    /**
     *  Initialize the ArrayTest object each time.
     */
    @Before
    public void setUp() throws Exception
    {
        obj = new ArrayTest();
    }

    @Test
    public void testCommonEnd_123_73()
    {
        int[] a = {1, 2, 3};
        int[] b = {7, 3};
        assertTrue(invoke(obj, Boolean.class, 
                "commonEnd", a, b));
    }

    @Test
    public void testCommonEnd_123_732()
    {
        int[] a = {1, 2, 3};
        int[] b = {7, 3, 2};
        assertFalse(invoke(obj, Boolean.class, 
                "commonEnd", a, b));
    }

    @Test
    public void testCommonEnd_123_13()
    {
        int[] a = {1, 2, 3};
        int[] b = {1, 3};
        assertTrue(invoke(obj, Boolean.class, 
                "commonEnd", a, b));

    }

    @Test
    public void testCommonEnd_123_1()
    {
        int[] a = {1, 2, 3};
        int[] b = {1};
        assertTrue(invoke(obj, Boolean.class, 
                "commonEnd", a, b));

    }

    @Test
    public void testCommonEnd_123_2()
    {
        int[] a = {1, 2, 3};
        int[] b = {2};
        assertFalse(invoke(obj, Boolean.class, 
                "commonEnd", a, b));

    }
}
