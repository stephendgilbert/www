import static net.sf.webcat.ReflectionSupport.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestRotateLeft3
{
    private ArrayTest obj;
    
         
    @Before
    public void setUp() throws Exception
    {
        obj = new ArrayTest();
    }

    @Test
    public void testRotateLeft3_123()
    {
        int[] a = {1, 2, 3};
        int[] b = {2, 3, 1};
        invoke(obj, "rotateLeft3", a);
        assertTrue(a[0] == b[0] && a[1] == b[1] && a[2] == b[2]);
    }

    @Test
    public void testRotateLeft3_5119()
    {
        int[] a = {5, 11, 9};
        int[] b = {11, 9, 5};
        invoke(obj, "rotateLeft3", a);
        assertTrue(a[0] == b[0] && a[1] == b[1] && a[2] == b[2]);
    }    

    @Test
    public void testRotateLeft3_700()
    {
        int[] a = {7, 0, 0};
        int[] b = {0, 0, 7};
        invoke(obj, "rotateLeft3", a);
        assertTrue(a[0] == b[0] && a[1] == b[1] && a[2] == b[2]);
    }
    
    @Test
    public void testRotateLeft3_121()
    {
        int[] a = {1, 2, 1};
        int[] b = {2, 1, 1};
        invoke(obj, "rotateLeft3", a);
        assertTrue(a[0] == b[0] && a[1] == b[1] && a[2] == b[2]);
    }
    
    @Test
    public void testRotateLeft3_2113()
    {
        int[] a = {2, 11, 3};
        int[] b = {11, 3, 2};
        invoke(obj, "rotateLeft3", a);
        assertTrue(a[0] == b[0] && a[1] == b[1] && a[2] == b[2]);
    }
    
    @Test
    public void testRotateLeft3_065()
    {
        int[] a = {0, 6, 5};
        int[] b = {6, 5, 0};
        invoke(obj, "rotateLeft3", a);
        assertTrue(a[0] == b[0] && a[1] == b[1] && a[2] == b[2]);
    }
}
