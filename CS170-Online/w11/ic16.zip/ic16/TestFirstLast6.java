import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestFirstLast6
{
    private ArrayTest obj;
    
    @Before
    public void setUp() throws Exception
    {
        obj = new ArrayTest();
    }

    @Test
    public void testFirstLast6_1_2_6()
    {
        assertTrue(obj.firstLast6(new int[]{1,2,6}));
    }
    
    @Test
    public void testFirstLast6_6_1_2_3()
    {
        assertTrue(obj.firstLast6(new int[]{6,1,2,3}));
    }

    @Test
    public void testFirstLast6_3_2_1()
    {
        assertFalse(obj.firstLast6(new int[]{3,2,1}));
    }

    @Test
    public void testFirstLast6_3_6_1()
    {
        assertFalse(obj.firstLast6(new int[]{3,6,1}));
    }

    @Test
    public void testFirstLast6_3_6()
    {
        assertTrue(obj.firstLast6(new int[]{3,6}));
    }

    @Test
    public void testFirstLast6_6()
    {
        assertTrue(obj.firstLast6(new int[]{6}));
    }


}
