import static net.sf.webcat.ReflectionSupport.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestCountEvens
{
    private ArrayTest obj;
    
    @Before
    public void setUp() throws Exception
    {
        obj = new ArrayTest();
    }

    @Test
    public void testCountEvens_21234()
    {
        int[] a = {2, 1, 2, 3, 4};
        assertEquals(3, 
                invoke(obj, Integer.class, "countEvens", a));
    }

    @Test
    public void testCountEvens_222()
    {
        int[] a = {2, 2, 2};
        assertEquals(3, 
                invoke(obj, Integer.class, "countEvens", a));
    }

    @Test
    public void testCountEvens_135()
    {
        int[] a = {1, 3, 5};
        assertEquals(0, 
                invoke(obj, Integer.class, "countEvens", a));
    }

    @Test
    public void testCountEvens_EmptyArray()
    {
        int[] a = {};
        assertEquals(0, 
                invoke(obj, Integer.class, "countEvens", a));
    }

    @Test
    public void testCountEvens_11901()
    {
        int[] a = {11,9,0,1};
        assertEquals(1, 
                invoke(obj, Integer.class, "countEvens", a));
    }

    @Test
    public void testCountEvens_21190()
    {
        int[] a = {2, 11, 9, 0};
        assertEquals(2, 
                invoke(obj, Integer.class, "countEvens", a));
    }
    
    @Test
    public void testCountEvens_22()
    {
        int[] a = {2, 2};
        assertEquals(2, 
                invoke(obj, Integer.class, "countEvens", a));
    }
}
