import static net.sf.webcat.ReflectionSupport.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestEvenInts
{
    private ArrayTest obj;

    @Before
    public void setUp() throws Exception
    {
        obj = new ArrayTest();
    }

    private boolean sameArrays(int[] a, int[] b)
    {
        if (a.length != b.length) return false;
        for (int i = 0; i < a.length; i++)
            if (a[i] != b[i])
                return false;
        return true;
    }
    
    @Test
    public void testEvenInts1_3_5_2()
    {
        int[] a = {1, 3, 5, 2};
        int[] a2 = {1, 3, 5, 2};
        int[] b = {2};
        int[] c = invoke(obj, a.getClass(), "evenInts", a);
        assertTrue("evenInts({1, 3, 5, 2}) -> {2}", 
                sameArrays(b, c));
        
        assertTrue("array modified by evenInts()",
                sameArrays(a, a2));
    }

    @Test
    public void testEvenInts1_2_5_2()
    {
        int[] a = {1, 2, 5, 2};
        int[] a2 = {1, 2, 5, 2};
        int[] b = {2, 2};
        int[] c = invoke(obj, a.getClass(), "evenInts", a);
        assertTrue("evenInts({1, 2, 5, 2}) -> {2, 2}", 
                sameArrays(b, c));
        
        assertTrue("array modified by evenInts()",
                sameArrays(a, a2));
    }

    @Test
    public void testEvenInts1_3_5_3()
    {
        int[] a = {1, 3, 5, 3};
        int[] a2 = {1, 3, 5, 3};
        int[] b = {};
        int[] c = invoke(obj, a.getClass(), "evenInts", a);
        assertTrue("evenInts({1, 3, 5, 3}) -> {}", 
                sameArrays(b, c));
        
        assertTrue("array modified by evenInts()",
                sameArrays(a, a2));
    }

    @Test
    public void testEvenInts_Empty()
    {
        int[] a = {};
        int[] b = {};
        int[] c = invoke(obj, a.getClass(), "evenInts", a);
        assertTrue("evenInts({}) -> {}", 
                sameArrays(b, c));
    }
}
