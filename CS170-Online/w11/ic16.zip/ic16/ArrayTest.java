import acm.program.*;
/**
 *  Testing arrays in CS 170.
 *
 *  @author  Stephen Gilbert
 *  @version April 15, 2008
 */

public class ArrayTest extends ConsoleProgram
{
    /**
     * Given an array of int, return true if 6 appears as either
     * the first or last element in the array. You can assume that
     * the array will contain at least one element.
     */
    public boolean firstLast6(int[] nums)
    {
        int last = nums.length - 1;
        return nums[0] == 6 || nums[last] == 6;
    }
    
    
    /**
     * Test out different arrays.
     */
    public void run()
    {
        // Put your code for exercise 2 here
        
        // Put your code for exercise 3 here
        
        // Put your code for exercise 4 here
        
        // Code for exercise 5 here
        
        // Code for exercise 6 here
        
        // Code for exercise 7 here
        
        // Code for exercise 8 here
        
        // Code for exercise 11 here
    }

    // Define the method for exercise 9 here
    /**
     * The commonEnd method returns true if two arrays
     * have the same first element or the same last element.
     */
    
    
    // Define the method for exercise 10 here
    /**
     * The rotateLeft3 method is passed an array of int,
     * always of length 3. The method "rotates left" the 
     * elements of the array so that {1, 2, 3} becomes 
     * {2, 3, 1}. The method has no return value.
     */

    // Define the method for exercise 12 here
    /**
     * Counts the number of even ints in the array parameter.
     */

    // Define the method for exercise 13 here
    /**
     * Method evenInts returns a new array containing all
     * of the even numbers in the original array. The original
     * array is not modified.
     */
    

    /**
     * The standard Java entry point. DON'T MODIFY THIS METHOD.
     */
    public static void main(String[] args)
    {
        new ArrayTest().start(args);
    }
}
