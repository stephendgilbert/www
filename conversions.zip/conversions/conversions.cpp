#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main()
{
    cout << "stoi(\"42\")->" << stoi("42") << endl;
    cout << "stod(\"3.14159\")->" << stod("3.14159") << endl;
    cout << "stoi(\"3.14159\")->" << stoi("3.14159") << endl;
    cout << "stod(\"4NonBlondes\")->" << stod("4NonBlondes") << endl;
    cout << "stoi(\"UB-40\")->" << stoi("UB-40") << endl;
}
