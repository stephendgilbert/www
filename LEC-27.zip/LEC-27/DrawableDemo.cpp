#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>

const float kWinWidth = 640;
const float kWinHeight = 480;
template <typename T>
void update(const T& obj, float& dx, float& dy);

int main()
{
    // Set the main window
    sf::ContextSettings settings;
    settings.antialiasingLevel = 8;
    sf::RenderWindow window(sf::VideoMode(kWinWidth, kWinHeight), 
        "Vector of Drawable*", sf::Style::Default, settings);
    //window.setSize(kWinWidth, kWinHeight);  // prevent resizing
    window.setFramerateLimit(60);
    
    // Create a Shape
    float radius = 50.f;
    sf::CircleShape circle(radius);
    circle.setOrigin(radius / 2, radius / 2);
    circle.setFillColor(sf::Color::Green);
    circle.setOutlineThickness(-10.f);
    circle.setOutlineColor(sf::Color(250, 150, 100));
    circle.move(100.f, 100.f);

    // Some Text
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) { 
        std::cerr << "Cannot load font" << std::endl;
        return 1;
    }
    sf::Text text;
    text.setFont(font); // font is a sf::Font
    text.setString("Hello CS 150");
    text.setCharacterSize(32); // in pixels, not points!
    text.setFillColor(sf::Color::Yellow);
    text.setPosition(300.f, 100.f);

    // A Sprite
    sf::Texture texture;
    if (! texture.loadFromFile("as.png")) {
        std::cerr << "Cannot load texture: as.png" << std::endl;
        return 2;
    }
    texture.setSmooth(true);
    sf::Sprite sprite;
    sprite.setTexture(texture);
    sprite.setPosition(250.f, 200.f);
    
    // Put all the items in a vector
    std::vector<sf::Drawable*> objects{&circle, &text, &sprite};
    
    // Keep track of position of objects
    float cdx = 2.f, cdy = 2.f;         // circle movement
    float sdx = -2.f, sdy = -2.f;       // sprite movement
    
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }


        window.clear();
        // Draw all of the objects
        for (auto object : objects)
            window.draw(*object);
        
        window.display();
        
        // Update position of both objects
        update(circle, cdx, cdy);
        circle.move(cdx, cdy);
        update(sprite, sdx, sdy);
        sprite.move(sdx, sdy);
    }

    return 0;
}

template <typename T>
void update(const T& obj, float& dx, float& dy) {
    auto rect = obj.getGlobalBounds();
    if (rect.left <= 0) dx = -dx;
    if (rect.top <= 0) dy = -dy;
    if (rect.left + rect.width >= kWinWidth) dx = -dx;
    if (rect.top + rect.height >= kWinHeight) dy = -dy;
}
