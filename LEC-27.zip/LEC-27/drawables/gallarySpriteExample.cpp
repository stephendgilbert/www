#include <SFML/Graphics.hpp>
#include "SelbaWard/GallerySprite.cpp"

int main()
{
    sf::Texture texture;
    if (!texture.loadFromFile("resources/Person Walk Animation SpriteSheet.png"))
        return EXIT_FAILURE;

    sf::RenderWindow window(sf::VideoMode(800, 600), "Gallery Sprite Basics Tutorial");

    sf::RectangleShape floor;
    floor.setFillColor(sf::Color(64, 64, 64));
    floor.setSize(sf::Vector2f(window.getSize()));
    floor.setScale({ 1.f, 0.5f });
    floor.setPosition({ 0.f, window.getSize().y / 2.f });

    sw::GallerySprite sprite(texture);
    sprite.setScale({ 10.f, 10.f });
    sprite.setPosition(sf::Vector2f(window.getSize() / 2u));

    sprite.addExhibit({ {  1.f, 1.f, 12.f, 21.f } });
    sprite.addExhibit({ { 14.f, 1.f,  9.f, 20.f } });
    sprite.addExhibit({ { 24.f, 1.f,  6.f, 21.f } });
    sprite.addExhibit({ { 31.f, 1.f,  9.f, 22.f } });
    sprite.addExhibit({ { 41.f, 1.f, 12.f, 21.f } });
    sprite.addExhibit({ { 54.f, 1.f,  9.f, 20.f } });
    sprite.addExhibit({ { 64.f, 1.f,  6.f, 21.f } });
    sprite.addExhibit({ { 71.f, 1.f,  9.f, 22.f } });

    sprite.setAnchor(1, { 6.f, 21.f });
    sprite.setAnchor(2, { 5.f, 20.f });
    sprite.setAnchor(3, { 3.f, 21.f });
    sprite.setAnchor(4, { 5.f, 22.f });
    sprite.setAnchor(5, { 6.f, 21.f });
    sprite.setAnchor(6, { 5.f, 20.f });
    sprite.setAnchor(7, { 3.f, 21.f });
    sprite.setAnchor(8, { 5.f, 22.f });

    sf::Clock clock;

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            switch (event.type)
            {
            case sf::Event::Closed:
                window.close();
                break;
            }
        }

        constexpr unsigned int numberOfMillisecondsPerFrame{ 100u };
        sprite.set((clock.getElapsedTime().asMilliseconds() / numberOfMillisecondsPerFrame) % sprite.getNumberOfExhibits() + 1);

        window.clear(sf::Color(128, 128, 128));
        window.draw(floor);
        window.draw(sprite);
        window.display();
    }

    return EXIT_SUCCESS;
}
