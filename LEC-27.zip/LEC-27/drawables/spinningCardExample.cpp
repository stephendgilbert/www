#include <SFML/Graphics.hpp>
#include "SelbaWard/SpinningCard.hpp"
int main()
{
    sf::RenderWindow window(sf::VideoMode(130, 170), "Spinning Card simple example");
    sf::Texture texture;
    if (!texture.loadFromFile("resources/Card Face - SFML.png")) return EXIT_FAILURE;
    sf::Sprite sprite(texture);
    sprite.setOrigin( { -10.f, -10.f });
    sw::SpinningCard spinningCard(sprite);
    sf::Clock clock;
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event)) if (event.type == sf::Event::Closed) window.close();
        spinningCard.spin(clock.getElapsedTime().asSeconds() * 200.f);
        window.clear();
        window.draw(spinningCard);
        window.display();
    }
    return EXIT_SUCCESS;
}

#include "SelbaWard/SpinningCard.cpp"
