/**
    @file lec27.cpp
    @author your name here
    @version what day and meeting time
*/
#include <string>
#include <stdexcept>
#include <iomanip>
#include <sstream>
using namespace std;

#include "lec27.h"

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

// Add your implementation here



/////////////// Student Tests ////////////////////////////
#include <iostream>
int run()
{
	cout << "Student testing" << endl;
	return 0;
}
