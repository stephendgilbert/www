/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec05.cpp
 */
#include <string>
using namespace std;

string student = "WHO AM I?";  // Add your Canvas login name

/**
 * The to_French_gender function
 * @param country (a const string&)
 * @return the gendered country name
 *
 * The rules for French gender:
 * - Add a prefix (le, la, l', les) to indicate gender
 * - Feminine names are prefaced with la, and masculine names with le
 * - Names ending in 'e' or 'o' are feminine with these exceptions, which are masculine
 *   > Belize, Cambodge, Honduras, Mexique, Mozambique, Costa Rica and Zimbabwe
 * - Names starting with a vowel use l' such as l'Afghanistan
 * - Plurals are prefaces with les
 *   > A name is plural if it ends in es, is, as, or os, or if it starts with iles (islands)
 * - The following names have no prefix
 *   > Israel, Madagascar, Sri Lanka, Singapore, Monaco, Cuba and Cypres
 */
string to_French_gender(const string& country)
{
	string result;
    
    // Add your code here
    
    
    return result;
}

/////////////// Optional Student Code /////////////////
int run()
{
    return 0;
}
