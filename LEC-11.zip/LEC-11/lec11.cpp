/**
 * @file lec11.cpp
 * @author Your Name Here
 * @version Section and Semester Here
 */
#include <string>
#include <iostream>
#include <cctype>
using namespace std;

string student = "WHO ARE YOU?";  // Add your Canvas login name

#include "lec11.h"

// Implement your functions here


//////////// Student tests or run
int run()
{
    cout << "Student Testing" << endl;
    return 0;
}
