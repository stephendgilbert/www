/**
 * @file lec11.h
 * @author Stephen Gilbert
 * @version CS 150 Function Declarations
 */
#ifndef LEC11_H
#define LEC11_H
#include <iostream>

/**
 * The CS 150 encryption namespace
 */
namespace enc {

    /**
     * Implements the Caesar cipher.
     * @param in the stream containing the plaintext.
     * @param out the stream containing the ciphertext.
     * @param key the key used to shift the characters (rightward).
     */
    void cipher(std::istream& in, std::ostream& out, unsigned key);

    /**
     * Implements the Caesar cipher.
     * @param in the stream containing the plaintext.
     * @param out the stream containing the ciphertext.
     * @param key the key used to shift the characters (leftward).
     */
    void plaintext(std::istream& in, std::ostream& out, unsigned key);
};

/**
 * Strips all comments from a C++ program.
 * This is a state filter program.
 * It reads from standard input and writes to standard output.
 * It removes both single line and multiline comments.
 */
void strip();

#endif

