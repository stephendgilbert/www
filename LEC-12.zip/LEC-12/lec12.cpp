/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec12.cpp
 */
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
using namespace std;

string student = "WHO AM I?"; // Add your Canvas/occ-email ID

#include "lec12.h"

// Write your functions here



///////////////// Student Testing /////////////////////////
int run()
{
    cout << "Student tests" << endl;
    return 0;
}
