/**
    @file lec12.h
    @author Stephen Gilbert
    @version CS 150 Function Declarations
*/
#ifndef LEC12_H
#define LEC12_H

#include <string>

/**
 * Opens and processes the data sets in fileName.
 * Returns as a string the count and the average.
 * @param fileName name of the file.
 * @return the stats as described in the handout.
 */
std::string dataSets(const std::string& fileName);

/**
 * The following functions are modeled after the simpleio.h
 * header file in the stanford c++ libraries
 * https://web.stanford.edu/dept/cs_edu/resources/cslib_docs/simpio.html
 */

/**
 * Reads a line of text from user input and returns that line as a string.
 * The newline character that terminates the input is not stored as part
 * of the return value.
 *
 * @param prompt optional prompt. If supplied, printed before reading the value.
 *      If no ending space supplied, one is added.
 * @return the string entered by the user. If the user only enters a newline,
 *         the return value is the empty string.
 *
 * Note that this is get_line with an underscore.
 * You'll use the standard library function getline to implement this.
 */
std::string get_line(const std::string& prompt="");

/**
 * Reads a complete line from user input and scans it as an integer.
 * @param prompt optional prompt. If supplied, printed before reading the value.
 *      If no ending space supplied, one is added.
 * @param reprompt optional reprompt message is displayed before asking the user
 *      to reenter an illegal value. If no reprompt argument is given, the message
 *      defaults to "Illegal integer format. Try again.".
 * @return if the scan succeeds, the integer value is returned.
 *      If the argument is not a legal integer or if extraneous characters
 *      (other than whitespace) appear in the string, the user is given a chance
 *      to reenter the value.
 */
int get_int(const std::string& prompt="", const std::string& reprompt="Illegal integer format. Try again.");


/**
 * Reads a complete line from user input and scans it as an double.
 * @param prompt optional prompt. If supplied, printed before reading the value.
 *      If no ending space supplied, one is added.
 * @param reprompt optional reprompt message is displayed before asking the user
 *      to reenter an illegal value. If no reprompt argument is given, the message
 *      defaults to "Illegal numeric format. Try again.".
 * @return if the scan succeeds, the double value is returned.
 *      If the argument is not a legal integer or if extraneous characters
 *      (other than whitespace) appear in the string, the user is given a chance
 *      to reenter the value.
 */
double get_real(const std::string& prompt="", const std::string& reprompt="Illegal numeric format. Try again.");

/**
 * Reads a complete line from user input and treats it as a yes-or-no answer to a question.
 * @param prompt optional prompt. If supplied, printed before reading the value.
 *      If no ending space supplied, one is added.
 * @param reprompt optional reprompt message The optional reprompt message is displayed before
 *      asking the user to reenter an illegal value. If no reprompt argument is given, the
 *      message defaults to "Please type a word that starts with 'Y' or 'N'.".
 * @return true if the line typed begins with a 'y' or 'Y', and returns false if it begins with a 'n' or 'N'.
 *      If the user's input is not a valid Y or N response, they are asked to reenter.
 */
bool get_yn(const std::string& prompt="", const std::string& reprompt="Please type a word that starts with 'Y' or 'N'.");

#endif
