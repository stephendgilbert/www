/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec04.cpp
 */
#include <iostream>
#include <iomanip>
#include <string>
#include <string_view>
using namespace std;

string student = "Who Are You?";  // Add your Canvas login name
extern string assignment;

// Function Prototypes
void print_title();
string get_input();
double letter_to_points(string_view letter_grade);
void print_report(double points);

// Constants
const double kInvalidCombination = -1.0;
const double kInvalidInput = -2.0;

/**
 * Calculates the grade points for a letter grade.
 * @return 0 for success.
 */
int run()
{
	print_title();
	string letter_grade = get_input();
	double points = letter_to_points(letter_grade);
	print_report(points);

    return 0;
}

// Implement your functions here
