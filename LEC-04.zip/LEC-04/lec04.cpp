/**
 *  @author Put your name here
 *  @date Put the date here
 *  @file lec04.cpp
 */
#include <iostream>
#include <iomanip>
#include <string>
#include <string_view>
using namespace std;

string student = "Who Are You?";  // Add your Canvas login name
extern string assignment;

// Function Prototypes
void printTitle();
string getInput();
double letterToPoints(string_view letterGrade);
void printReport(double points);

// Constants
const double kInvalidCombination = -1.0;
const double kInvalidInput = -2.0;

/**
 * Calculates the grade points for a letter grade.
 * @return 0 for success.
 */
int run()
{
	printTitle();
	string letterGrade = getInput();
	double points = letterToPoints(letterGrade);
	printReport(points);

    return 0;
}

// Implement your functions here
